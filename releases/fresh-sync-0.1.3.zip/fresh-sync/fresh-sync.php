<?php
/**
 * Plugin Name:       Fresh Sync — цены и остатки из 1С
 * Description:       Обновляет цену и остаток товаров WooCommerce по GUID из 1С (CSV-выгрузка или OData 1С:Фреш). Название, описание, атрибуты и картинки не изменяются.
 * Version:           0.1.3
 * Requires at least: 5.7
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Text Domain:       fresh-sync
 * Update URI:        https://github.com/SargeMadovsky/fresh-sync-releases
 */

defined( 'ABSPATH' ) || exit;

define( 'FSYNC_VERSION', '0.1.3' );
define( 'FSYNC_FILE', __FILE__ );
define( 'FSYNC_DIR', plugin_dir_path( __FILE__ ) );

require_once FSYNC_DIR . 'includes/class-fsync-updater.php';
require_once FSYNC_DIR . 'includes/class-fsync-options.php';
require_once FSYNC_DIR . 'includes/class-fsync-source.php';
require_once FSYNC_DIR . 'includes/class-fsync-engine.php';
require_once FSYNC_DIR . 'includes/class-fsync-admin.php';

// Обновления из репозитория сборок на GitHub (не с wordpress.org).
FSYNC_Updater::init();

add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

add_action(
	'plugins_loaded',
	function () {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p>Fresh Sync: требуется активный WooCommerce.</p></div>';
				}
			);
			return;
		}
		FSYNC_Engine::init();
		FSYNC_Admin::init();
	}
);

register_deactivation_hook(
	__FILE__,
	function () {
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( 'fsync_cron' );
			as_unschedule_all_actions( 'fsync_tick' );
		}
		wp_clear_scheduled_hook( 'fsync_tick' );
		delete_transient( 'fsync_lock' );
	}
);
