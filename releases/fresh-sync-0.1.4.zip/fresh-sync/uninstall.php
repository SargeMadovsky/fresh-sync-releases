<?php
/**
 * Удаление плагина: стираются его настройки (в том числе логин и пароль OData), состояние запусков,
 * расписание и временные файлы. GUID 1С в товарах (мета-поле, общее с EDI) не трогается.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'fsync_options', 'fsync_run', 'fsync_status', 'fsync_baseline', 'fsync_fails', 'fsync_update_last' ) as $fsync_opt ) {
	delete_option( $fsync_opt );
}
delete_transient( 'fsync_lock' );
delete_transient( 'fsync_nudge' );
delete_site_transient( 'fsync_update_manifest' );

if ( function_exists( 'as_unschedule_all_actions' ) ) {
	as_unschedule_all_actions( 'fsync_cron' );
	as_unschedule_all_actions( 'fsync_tick' );
}
wp_clear_scheduled_hook( 'fsync_cron' );
wp_clear_scheduled_hook( 'fsync_tick' );

$fsync_up = wp_upload_dir( null, false );
if ( ! empty( $fsync_up['basedir'] ) ) {
	$fsync_dir = rtrim( $fsync_up['basedir'], '/\\' ) . '/fresh-sync';
	if ( is_dir( $fsync_dir ) ) {
		foreach ( array_merge( (array) glob( $fsync_dir . '/run-*.json*' ), array( $fsync_dir . '/index.html', $fsync_dir . '/.htaccess' ) ) as $fsync_f ) {
			if ( is_file( $fsync_f ) ) {
				@unlink( $fsync_f ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			}
		}
		@rmdir( $fsync_dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
	}
}
