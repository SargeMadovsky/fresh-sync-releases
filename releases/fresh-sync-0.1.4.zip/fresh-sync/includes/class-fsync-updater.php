<?php
/**
 * Обновления из публичного репозитория сборок на GitHub (SargeMadovsky/fresh-sync-releases),
 * а не с wordpress.org. Исходники — в приватном репозитории SargeMadovsky/fresh-sync.
 *
 * Заголовок плагина содержит Update URI с хостом github.com, поэтому WordPress вызывает
 * фильтр update_plugins_github.com. Отвечаем данными из update.json; дальше всё штатно:
 * кнопка «Обновить», автообновление, окно «Подробнее».
 *
 * GitHub спрашивается только из WP-Cron (на странице админки — сохранённая копия),
 * потому что с российских хостингов GitHub бывает медленным. Сборки кладёт GitHub Actions
 * по тегу v* (.github/workflows/release.yml). Схема та же, что у плагина LogShield.
 */
defined( 'ABSPATH' ) || exit;

class FSYNC_Updater {

	const REPO       = 'SargeMadovsky/fresh-sync-releases';
	const MANIFEST   = 'https://raw.githubusercontent.com/SargeMadovsky/fresh-sync-releases/main/update.json';
	const PREFIX     = 'https://raw.githubusercontent.com/SargeMadovsky/fresh-sync-releases/';
	const UPDATE_URI = 'https://github.com/SargeMadovsky/fresh-sync-releases';
	const SLUG       = 'fresh-sync';
	const CACHE      = 'fsync_update_manifest';
	const LAST       = 'fsync_update_last'; // [ time, ms, ok, error ].
	const FETCH_HOOK = 'fsync_update_fetch';
	const TIMEOUT    = 5;
	const CACHE_TTL  = HOUR_IN_SECONDS;
	const FAIL_TTL   = 30 * MINUTE_IN_SECONDS;
	const KEEP       = 30 * DAY_IN_SECONDS;

	public static function init() {
		add_filter( 'update_plugins_github.com', array( __CLASS__, 'check' ), 10, 3 );
		add_filter( 'plugins_api', array( __CLASS__, 'info' ), 20, 3 );
		add_filter( 'upgrader_source_selection', array( __CLASS__, 'fix_folder' ), 10, 4 );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'pre_download' ), 10, 4 );
		add_action( 'load-update-core.php', array( __CLASS__, 'maybe_flush' ) );
		add_action( self::FETCH_HOOK, array( __CLASS__, 'fetch_cron' ) );
	}

	public static function basename() {
		return (string) apply_filters( 'fsync_plugin_basename', plugin_basename( FSYNC_FILE ) );
	}

	/** Рабочая копия из git: обновление стёрло бы её, поэтому такие копии не обновляем. */
	public static function is_dev_checkout() {
		return (bool) apply_filters( 'fsync_is_dev_checkout', file_exists( FSYNC_DIR . '.git' ) );
	}

	public static function check( $update, $plugin_data, $plugin_file ) {
		if ( self::basename() !== $plugin_file || self::is_dev_checkout() ) {
			return $update;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $update;
		}
		return array_merge( self::item( $m ), array( 'version' => $m['version'] ) );
	}

	private static function item( array $m ) {
		return array(
			'slug'         => self::SLUG,
			'url'          => self::UPDATE_URI,
			'package'      => $m['download_url'],
			'tested'       => isset( $m['tested'] ) ? $m['tested'] : '',
			'requires_php' => isset( $m['requires_php'] ) ? $m['requires_php'] : '',
			'icons'        => array(),
		);
	}

	public static function info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! isset( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $result;
		}
		$data = get_plugin_data( FSYNC_FILE, false, false );
		return (object) array(
			'name'          => 'Fresh Sync',
			'slug'          => self::SLUG,
			'version'       => $m['version'],
			'author'        => 'Fresh Sync',
			'homepage'      => self::UPDATE_URI,
			'requires'      => isset( $m['requires'] ) ? $m['requires'] : '',
			'requires_php'  => isset( $m['requires_php'] ) ? $m['requires_php'] : '',
			'tested'        => isset( $m['tested'] ) ? $m['tested'] : '',
			'last_updated'  => isset( $m['released'] ) ? $m['released'] : '',
			'download_link' => $m['download_url'],
			'sections'      => array(
				'description' => '<p>' . esc_html( isset( $data['Description'] ) ? $data['Description'] : '' ) . '</p>',
				'changelog'   => self::changelog_html( isset( $m['changelog'] ) ? $m['changelog'] : '' ),
			),
		);
	}

	/** Если плагин стоит в папке с другим именем — переименовываем распакованное под неё. */
	public static function fix_folder( $source, $remote_source, $upgrader, $hook_extra = array() ) {
		if ( empty( $hook_extra['plugin'] ) || self::basename() !== $hook_extra['plugin'] ) {
			return $source;
		}
		global $wp_filesystem;
		$want = trailingslashit( $remote_source ) . dirname( self::basename() ) . '/';
		if ( untrailingslashit( $source ) === untrailingslashit( $want ) ) {
			return $source;
		}
		if ( ! $wp_filesystem || ! $wp_filesystem->move( $source, $want, true ) ) {
			return new WP_Error( 'fsync_rename', 'Не удалось переименовать папку обновления Fresh Sync.' );
		}
		return $want;
	}

	/** Скачиваем архив сами и сверяем sha256 и размер из update.json до распаковки. */
	public static function pre_download( $reply, $package, $upgrader = null, $hook_extra = array() ) {
		if ( false !== $reply || ! is_string( $package ) || '' === $package ) {
			return $reply;
		}
		$m = self::manifest( false );
		if ( ! $m || empty( $m['sha256'] ) || $package !== $m['download_url'] ) {
			return $reply;
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$file = download_url( $package, 300, false );
		if ( is_wp_error( $file ) ) {
			return new WP_Error( 'download_failed', 'Не удалось скачать обновление Fresh Sync.', $file->get_error_message() );
		}
		$error = '';
		$size  = @filesize( $file );
		if ( isset( $m['size'] ) && $size !== $m['size'] ) {
			$error = sprintf( 'размер %d байт, а в update.json — %d', (int) $size, (int) $m['size'] );
		} else {
			$hash = hash_file( 'sha256', $file );
			if ( ! is_string( $hash ) || ! hash_equals( $m['sha256'], $hash ) ) {
				$error = 'контрольная сумма sha256 не совпадает с update.json';
			}
		}
		if ( '' !== $error ) {
			@unlink( $file );
			return new WP_Error( 'fsync_checksum', 'Архив обновления Fresh Sync повреждён или подменён (' . $error . '). Обновление не установлено, текущая версия не тронута.' );
		}
		return $file;
	}

	/** Строка для страницы настроек: когда и как прошла последняя проверка. */
	public static function last_check_text() {
		if ( self::is_dev_checkout() ) {
			return 'не проверяется (рабочая копия из git)';
		}
		$l = get_option( self::LAST );
		if ( ! is_array( $l ) ) {
			return 'GitHub ещё не опрашивался.';
		}
		$when = wp_date( 'd.m H:i', $l['time'] );
		$sec  = number_format( $l['ms'] / 1000, 1, ',', '' );
		return $l['ok'] ? sprintf( '%s, %s с — ответ получен', $when, $sec ) : sprintf( '%s, %s с — ошибка: %s', $when, $sec, $l['error'] );
	}

	public static function maybe_flush() {
		if ( ! isset( $_GET['force-check'] ) || ! current_user_can( 'update_plugins' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$c = get_site_transient( self::CACHE );
		if ( is_array( $c ) ) {
			$c['next'] = 0;
			set_site_transient( self::CACHE, $c, self::KEEP );
		}
		self::schedule();
		spawn_cron();
	}

	/** В обычном запросе GitHub не спрашивается: только сохранённая копия, а обновляет её WP-Cron. */
	public static function manifest( $allow_fetch = null ) {
		if ( null === $allow_fetch ) {
			$allow_fetch = wp_doing_cron();
		}
		$c     = get_site_transient( self::CACHE );
		$data  = is_array( $c ) && isset( $c['data'] ) && is_array( $c['data'] ) ? $c['data'] : null;
		$stale = ! is_array( $c ) || (int) ( isset( $c['next'] ) ? $c['next'] : 0 ) <= time();
		if ( ! $stale ) {
			return $data;
		}
		if ( $allow_fetch ) {
			return self::refresh();
		}
		self::schedule();
		return $data;
	}

	/** Запрос к GitHub. Неудача не стирает прошлую удачную копию. */
	public static function refresh() {
		$url   = (string) apply_filters( 'fsync_update_manifest_url', self::MANIFEST );
		$start = microtime( true );
		$res   = wp_remote_get( $url, array( 'timeout' => self::TIMEOUT, 'headers' => array( 'Accept' => 'application/json' ) ) );
		$ms    = (int) round( ( microtime( true ) - $start ) * 1000 );
		$data  = null;
		$error = '';
		if ( is_wp_error( $res ) ) {
			$error = $res->get_error_message();
		} elseif ( 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			$error = 'HTTP ' . (int) wp_remote_retrieve_response_code( $res );
		} else {
			$data = self::validate( json_decode( wp_remote_retrieve_body( $res ), true ) );
			if ( ! $data ) {
				$error = 'update.json не прошёл проверку';
			}
		}
		update_option( self::LAST, array( 'time' => time(), 'ms' => $ms, 'ok' => (bool) $data, 'error' => mb_substr( $error, 0, 300 ) ), false );

		$old  = get_site_transient( self::CACHE );
		$keep = is_array( $old ) && isset( $old['data'] ) && is_array( $old['data'] ) ? $old['data'] : null;
		set_site_transient( self::CACHE, array( 'data' => $data ? $data : $keep, 'next' => time() + ( $data ? self::CACHE_TTL : self::FAIL_TTL ) ), self::KEEP );
		return $data ? $data : $keep;
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::FETCH_HOOK ) ) {
			wp_schedule_single_event( time(), self::FETCH_HOOK );
		}
	}

	/** Фоновая задача: обновить update.json и сразу показать новую версию в списке обновлений. */
	public static function fetch_cron() {
		if ( self::is_dev_checkout() ) {
			return;
		}
		$m = self::refresh();
		if ( ! $m ) {
			return;
		}
		$t = get_site_transient( 'update_plugins' );
		if ( ! is_object( $t ) ) {
			return;
		}
		$file = self::basename();
		$cur  = isset( $t->checked[ $file ] ) ? $t->checked[ $file ] : FSYNC_VERSION;
		$item = (object) array_merge( self::item( $m ), array( 'id' => self::UPDATE_URI, 'plugin' => $file, 'new_version' => $m['version'] ) );
		if ( version_compare( $m['version'], $cur, '>' ) ) {
			if ( isset( $t->response[ $file ] ) && $t->response[ $file ]->new_version === $m['version'] ) {
				return;
			}
			$t->response[ $file ] = $item;
			unset( $t->no_update[ $file ] );
		} else {
			if ( ! isset( $t->response[ $file ] ) ) {
				return;
			}
			unset( $t->response[ $file ] );
			$t->no_update[ $file ] = $item;
		}
		set_site_transient( 'update_plugins', $t );
	}

	/** Версия вида 1.2.3 и ссылка на zip строго в репозитории сборок по https. */
	public static function validate( $m ) {
		if ( ! is_array( $m ) || ! isset( $m['version'], $m['download_url'] ) ) {
			return null;
		}
		if ( ! is_string( $m['version'] ) || ! preg_match( '~^\d+(\.\d+){1,3}$~', $m['version'] ) ) {
			return null;
		}
		$prefix = (string) apply_filters( 'fsync_update_package_prefix', self::PREFIX );
		if ( ! is_string( $m['download_url'] ) || 0 !== strpos( $m['download_url'], $prefix ) || '.zip' !== substr( $m['download_url'], -4 ) ) {
			return null;
		}
		$out = array( 'version' => $m['version'], 'download_url' => $m['download_url'] );
		if ( isset( $m['sha256'] ) && is_string( $m['sha256'] ) && preg_match( '~^[0-9a-f]{64}$~D', $m['sha256'] ) ) {
			$out['sha256'] = $m['sha256'];
		}
		if ( isset( $m['size'] ) && is_int( $m['size'] ) && $m['size'] > 0 ) {
			$out['size'] = $m['size'];
		}
		foreach ( array( 'requires', 'requires_php', 'tested', 'released', 'changelog' ) as $k ) {
			if ( isset( $m[ $k ] ) && is_string( $m[ $k ] ) ) {
				$out[ $k ] = $m[ $k ];
			}
		}
		return $out;
	}

	/** Список изменений: строки «- текст» → <ul>, остальное — заголовки. Всё экранируется. */
	public static function changelog_html( $text ) {
		$html = '';
		$list = false;
		foreach ( preg_split( '~\R~u', (string) $text ) ?: array() as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			if ( preg_match( '~^[-*]\s+(.*)$~u', $line, $mm ) ) {
				if ( ! $list ) {
					$html .= '<ul>';
					$list  = true;
				}
				$html .= '<li>' . esc_html( $mm[1] ) . '</li>';
				continue;
			}
			if ( $list ) {
				$html .= '</ul>';
				$list  = false;
			}
			$html .= '<h4>' . esc_html( $line ) . '</h4>';
		}
		if ( $list ) {
			$html .= '</ul>';
		}
		return '' !== $html ? $html : '<p>Нет описания изменений.</p>';
	}
}
