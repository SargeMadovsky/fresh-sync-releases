<?php
defined( 'ABSPATH' ) || exit;

/**
 * Вспомогательные функции нормализации.
 */
class FSYNC_Util {

	const EMPTY_GUID = '00000000-0000-0000-0000-000000000000';

	public static function guid( $s ) {
		return trim( strtolower( trim( (string) $s ) ), '{}' );
	}

	public static function is_guid( $s ) {
		return (bool) preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', (string) $s );
	}

	/** ISBN-13 (978/979) или ISBN-10; всё остальное — пустая строка. */
	public static function isbn( $s ) {
		$d = strtoupper( preg_replace( '/[^0-9Xx]/', '', (string) $s ) );
		if ( 13 === strlen( $d ) && preg_match( '/^97[89]\d{10}$/', $d ) ) {
			return $d;
		}
		if ( 10 === strlen( $d ) && preg_match( '/^\d{9}[\dX]$/', $d ) ) {
			return $d;
		}
		return '';
	}

	public static function num( $s ) {
		if ( is_int( $s ) || is_float( $s ) ) {
			return (float) $s;
		}
		$s = str_replace( array( "\xC2\xA0", ' ' ), '', (string) $s );
		$s = str_replace( ',', '.', $s );
		return is_numeric( $s ) ? (float) $s : null;
	}

	/** Строки CSV из 1С иногда приходят в Windows-1251. */
	public static function utf8( $s ) {
		$s = (string) $s;
		if ( '' === $s || mb_check_encoding( $s, 'UTF-8' ) ) {
			return $s;
		}
		return mb_convert_encoding( $s, 'UTF-8', 'Windows-1251' );
	}
}

/**
 * Источник: CSV-файл (путь внутри wp-content или URL).
 *
 * Ожидаемые колонки (регистр не важен): ID (GUID), Kod, Articul (ISBN), Naimenovanie,
 * Kategoriya (GUID группы), price, stock. Обязательна только ID.
 */
class FSYNC_Source_CSV {

	private $o;

	private static $aliases = array(
		'guid'  => array( 'id', 'guid', 'ref_key', 'идентификатор' ),
		'code'  => array( 'kod', 'code', 'код' ),
		'isbn'  => array( 'articul', 'artikul', 'article', 'артикул', 'isbn' ),
		'name'  => array( 'naimenovanie', 'name', 'наименование' ),
		'group' => array( 'kategoriya', 'group', 'gruppa', 'категория', 'группа' ),
		'price' => array( 'price', 'cena', 'цена' ),
		'stock' => array( 'stock', 'ostatok', 'остаток', 'количество' ),
	);

	public function __construct( array $o ) {
		$this->o = $o;
	}

	/**
	 * @return true|WP_Error  Заполняет $state['items'] и $state['src'].
	 */
	public function fetch( array &$state, $deadline ) {
		$loc = trim( (string) $this->o['csv_location'] );
		if ( '' === $loc ) {
			return new WP_Error( 'fsync', 'Не указан путь или URL файла CSV.' );
		}
		$tmp = '';
		if ( preg_match( '#^https?://#i', $loc ) ) {
			$resp = wp_remote_get( $loc, array( 'timeout' => 60 ) );
			if ( is_wp_error( $resp ) ) {
				return $resp;
			}
			$code = (int) wp_remote_retrieve_response_code( $resp );
			if ( 200 !== $code ) {
				return new WP_Error( 'fsync', 'CSV: HTTP ' . $code );
			}
			$tmp = tempnam( get_temp_dir(), 'fsync' );
			file_put_contents( $tmp, wp_remote_retrieve_body( $resp ) );
			$path = $tmp;
		} else {
			$path = self::safe_path( $loc );
			if ( is_wp_error( $path ) ) {
				return $path;
			}
		}
		$result = $this->parse( $path, $state );
		if ( $tmp ) {
			@unlink( $tmp );
		}
		return $result;
	}

	/** Локальный файл должен лежать внутри wp-content. */
	public static function safe_path( $loc ) {
		$real = realpath( $loc );
		if ( false === $real || ! is_readable( $real ) ) {
			return new WP_Error( 'fsync', 'CSV-файл не найден или недоступен: ' . $loc );
		}
		$roots = array( WP_CONTENT_DIR );
		$up    = wp_upload_dir();
		if ( ! empty( $up['basedir'] ) ) {
			$roots[] = $up['basedir'];
		}
		foreach ( $roots as $r ) {
			$rr = realpath( $r );
			if ( $rr && 0 === strpos( $real, $rr . DIRECTORY_SEPARATOR ) ) {
				return $real;
			}
		}
		return new WP_Error( 'fsync', 'CSV-файл должен лежать внутри wp-content (например, wp-content/uploads/fresh-sync/).' );
	}

	private function parse( $path, array &$state ) {
		$fh = fopen( $path, 'r' );
		if ( ! $fh ) {
			return new WP_Error( 'fsync', 'Не удалось открыть CSV.' );
		}
		$first = fgets( $fh );
		if ( false === $first ) {
			fclose( $fh );
			return new WP_Error( 'fsync', 'CSV пуст.' );
		}
		$first = FSYNC_Util::utf8( preg_replace( '/^\xEF\xBB\xBF/', '', $first ) );

		$delim = ',';
		$best  = substr_count( $first, ',' );
		foreach ( array( ';', "\t" ) as $d ) {
			$c = substr_count( $first, $d );
			if ( $c > $best ) {
				$best  = $c;
				$delim = $d;
			}
		}
		$header = array_map(
			function ( $v ) {
				return mb_strtolower( trim( (string) $v ) );
			},
			str_getcsv( rtrim( $first, "\r\n" ), $delim, '"', '\\' )
		);

		$col = array();
		foreach ( self::$aliases as $field => $names ) {
			foreach ( $header as $i => $name ) {
				if ( in_array( $name, $names, true ) ) {
					$col[ $field ] = $i;
					break;
				}
			}
		}
		if ( ! isset( $col['guid'] ) ) {
			fclose( $fh );
			return new WP_Error( 'fsync', 'В CSV нет колонки ID (GUID).' );
		}

		$items = array();
		$rows  = 0;
		$bad   = 0;
		$dups  = 0;
		while ( false !== ( $r = fgetcsv( $fh, 0, $delim, '"', '\\' ) ) ) {
			if ( array( null ) === $r ) {
				continue; // Пустая строка.
			}
			++$rows;
			$r   = array_map( array( 'FSYNC_Util', 'utf8' ), $r );
			$get = function ( $f ) use ( $col, $r ) {
				return ( isset( $col[ $f ] ) && isset( $r[ $col[ $f ] ] ) ) ? trim( $r[ $col[ $f ] ] ) : '';
			};
			$g   = FSYNC_Util::guid( $get( 'guid' ) );
			if ( ! FSYNC_Util::is_guid( $g ) || FSYNC_Util::EMPTY_GUID === $g ) {
				++$bad;
				continue;
			}
			if ( isset( $items[ $g ] ) ) {
				++$dups;
			}
			$it    = array(
				'code'  => $get( 'code' ),
				'isbn'  => FSYNC_Util::isbn( $get( 'isbn' ) ),
				'name'  => $get( 'name' ),
				'group' => FSYNC_Util::guid( $get( 'group' ) ),
			);
			$price = isset( $col['price'] ) ? FSYNC_Util::num( $get( 'price' ) ) : null;
			$stock = isset( $col['stock'] ) ? FSYNC_Util::num( $get( 'stock' ) ) : null;
			if ( null !== $price ) {
				$it['price'] = $price;
			}
			if ( null !== $stock ) {
				$it['stock'] = $stock;
			}
			$items[ $g ] = $it;
		}
		fclose( $fh );

		if ( ! $items ) {
			return new WP_Error( 'fsync', 'В CSV нет ни одной строки с корректным ID (GUID).' );
		}
		$state['items'] = $items;
		$state['src']   = array(
			'caps' => array(
				'stock' => isset( $col['stock'] ),
				'price' => isset( $col['price'] ),
			),
			'rows' => $rows,
			'bad'  => $bad,
			'dups' => $dups,
		);
		if ( ! empty( $this->o['flag_enabled'] ) ) {
			$state['notes'][] = 'Отбор по реквизиту работает только для источника OData; в CSV выгружайте только нужные позиции.';
		}
		if ( $bad ) {
			$state['notes'][] = "CSV: пропущено строк с некорректным ID — {$bad}.";
		}
		if ( $dups ) {
			$state['notes'][] = "CSV: повторяющихся ID — {$dups} (использована последняя строка).";
		}
		return true;
	}
}

/**
 * Источник: OData 1С:Фреш (стандартный интерфейс).
 *
 * Остатки берутся из виртуальной таблицы Balance() регистра накопления,
 * цены — из SliceLast() регистра сведений. Имена сущностей и полей настраиваются.
 */
class FSYNC_Source_OData {

	private $o;

	public function __construct( array $o ) {
		$this->o = $o;
	}

	private function url( $path, $suffix = '', $query = '' ) {
		$base = rtrim( $this->o['odata_base'], '/' );
		if ( '' === $path ) {
			return $base . '/' . $suffix . $query;
		}
		$parts = array_map( 'rawurlencode', explode( '/', $path ) );
		$enc   = str_replace( array( '%28', '%29' ), array( '(', ')' ), implode( '/', $parts ) );
		return $base . '/' . $enc . $suffix . $query;
	}

	/** Остатки регистра бухгалтерии читаются одним запросом (с $select строка маленькая), чтобы набор не менялся между страницами. */
	const STOCK_PAGE = 20000;

	/** Цены одного типа читаются из плоской таблицы записей регистра крупными страницами. */
	const PRICE_PAGE = 20000;

	/** Общее число строк набора из последнего ответа ($inlinecount) либо null. */
	private $last_count = null;

	private function get_json( $url ) {
		$this->last_count = null;
		// Сетевой сбой, 429 и 5xx — временные: один повтор, прежде чем считать запуск неудачным.
		for ( $try = 0; ; $try++ ) {
			$resp = wp_remote_get(
				$url,
				array(
					'timeout' => 60,
					'headers' => array(
						'Authorization' => 'Basic ' . base64_encode( $this->o['odata_user'] . ':' . $this->o['odata_pass'] ),
						'Accept'        => 'application/json',
					),
				)
			);
			$code = is_wp_error( $resp ) ? 0 : (int) wp_remote_retrieve_response_code( $resp );
			if ( $try < 1 && ( 0 === $code || 429 === $code || $code >= 500 ) ) {
				sleep( 2 );
				continue;
			}
			break;
		}
		if ( is_wp_error( $resp ) ) {
			return $resp;
		}
		$body = preg_replace( '/^\xEF\xBB\xBF/', '', (string) wp_remote_retrieve_body( $resp ) );
		if ( 200 !== $code ) {
			return new WP_Error( 'fsync_http_' . $code, 'OData: HTTP ' . $code . ' — ' . mb_substr( trim( wp_strip_all_tags( $body ) ), 0, 300 ) );
		}
		$j = json_decode( $body, true );
		if ( ! is_array( $j ) ) {
			return new WP_Error( 'fsync', 'OData: ответ не JSON: ' . mb_substr( $body, 0, 200 ) );
		}
		if ( isset( $j['odata.count'] ) && is_numeric( $j['odata.count'] ) ) {
			$this->last_count = (int) $j['odata.count'];
		}
		return $j;
	}

	/** Сервер отклонил сам запрос (не принял $filter/$select), а не «не смог ответить». Доступ (401/403) сюда не относится. */
	private static function rejected( $err ) {
		return is_wp_error( $err ) && preg_match( '/^fsync_http_4(?!01|03)\d\d$/', (string) $err->get_error_code() );
	}

	/**
	 * Набор в 1С изменился, пока читались страницы (продажа, новая карточка): часть строк могла
	 * прийти дважды или потеряться. Этап читается заново, после нескольких попыток — ошибка.
	 *
	 * @return true|WP_Error
	 */
	private function reread( array &$state, array &$s, $stage ) {
		$s['restarts'] = ( isset( $s['restarts'] ) ? (int) $s['restarts'] : 0 ) + 1;
		if ( $s['restarts'] > 3 ) {
			return new WP_Error( 'fsync', 'OData: данные в 1С менялись во время чтения либо страницы приходят с повторами (' . ( 'stock' === $stage ? 'остатки' : ( 'price' === $stage ? 'цены' : 'номенклатура' ) ) . '), три попытки подряд. Запуск остановлен, изменения не вносились.' );
		}
		$s['skip'] = 0;
		unset( $s['sig'], $s['count'], $s['rows'] );
		if ( 'stock' === $stage ) {
			$state['items'] = array(); // Остатки — первый этап, кроме них в позициях ещё ничего нет.
			unset( $s['acc_stats'] );
		} elseif ( 'price' === $stage ) {
			foreach ( $state['items'] as $g => $it ) {
				unset( $state['items'][ $g ]['price'], $state['items'][ $g ]['pp'] );
			}
		} else {
			$state['flags'] = array();
			unset( $state['seen'] );
		}
		return true;
	}

	/**
	 * Сверка числа строк набора между страницами и в конце этапа.
	 *
	 * @param bool $last Последняя страница этапа.
	 * @return bool false — набор изменился, этап нужно перечитать.
	 */
	private function consistent( array &$s, $got, $last ) {
		$s['rows'] = ( isset( $s['rows'] ) ? (int) $s['rows'] : 0 ) + (int) $got;
		if ( null === $this->last_count ) {
			return true; // Сервер не вернул счётчик — сверять нечем.
		}
		if ( ! isset( $s['count'] ) ) {
			$s['count'] = $this->last_count;
		}
		return $s['count'] === $this->last_count && ( ! $last || $s['rows'] === $s['count'] );
	}

	private function page( $path, $skip, $filter, $top = null, $orderby = '', $select = '', $count = false ) {
		$top = null === $top ? (int) $this->o['odata_page_size'] : (int) $top;
		$q   = '?$format=json&$top=' . $top . '&$skip=' . (int) $skip;
		if ( $count ) {
			$q .= '&$inlinecount=allpages';
		}
		if ( '' !== $filter ) {
			$q .= '&$filter=' . rawurlencode( $filter );
		}
		if ( '' !== $orderby ) {
			$q .= '&$orderby=' . rawurlencode( $orderby );
		}
		if ( '' !== $select ) {
			$q .= '&$select=' . rawurlencode( $select );
		}
		$j = $this->get_json( $this->url( $path, '', $q ) );
		if ( is_wp_error( $j ) ) {
			return $j;
		}
		return ( isset( $j['value'] ) && is_array( $j['value'] ) ) ? $j['value'] : array();
	}

	/**
	 * Возобновляемая загрузка: возвращает true (готово), false (нужен ещё тик) или WP_Error.
	 */
	public function fetch( array &$state, $deadline ) {
		$o = $this->o;
		if ( '' === trim( $o['odata_base'] ) ) {
			return new WP_Error( 'fsync', 'Не указан адрес OData.' );
		}
		if ( empty( $state['src'] ) ) {
			$stages = array();
			if ( $o['update_stock'] ) {
				$stages[] = 'stock';
			}
			if ( $o['update_price'] ) {
				if ( '' !== $o['odata_price_type_guid'] ) {
					$stages[] = 'price';
				} else {
					$state['notes'][] = 'Тип цен (GUID) не задан — цены не обновляются.';
				}
			}
			$caps = array(
				'stock' => in_array( 'stock', $stages, true ),
				'price' => in_array( 'price', $stages, true ),
			);
			if ( ! empty( $o['flag_enabled'] ) ) {
				// Отбор по реквизиту: справочник читается сразу после остатков, и цены собираются
				// только для отобранных позиций (а не для всей номенклатуры с историей цен).
				$at = in_array( 'stock', $stages, true ) ? 1 : 0;
				array_splice( $stages, $at, 0, array( 'flags' ) );
			} elseif ( $o['link_by_sku'] || $o['create_new'] ) {
				$stages[] = 'flags'; // Последним: код/название/ISBN для уже прочитанных позиций.
			}
			$state['src'] = array(
				'stages' => $stages,
				'i'      => 0,
				'skip'   => 0,
				'pages'  => 0,
				'caps'   => $caps,
			);
		}
		$s = &$state['src'];
		while ( $s['i'] < count( $s['stages'] ) ) {
			if ( microtime( true ) > $deadline ) {
				return false;
			}
			$acc_mode = false;
			if ( 'flags' === $s['stages'][ $s['i'] ] ) {
				$r = $this->flags_page( $state, $s );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
				continue;
			}
			if ( 'stock' === $s['stages'][ $s['i'] ] ) {
				$stage    = 'stock';
				$path     = $o['odata_stock_entity'];
				$item     = $o['odata_stock_item'];
				$field    = $o['odata_stock_field'];
				$acc_mode = ( 0 === strpos( $path, 'AccountingRegister_' ) );
				$filter   = ( ! $acc_mode && '' !== $o['odata_warehouse_guid'] ) ? $o['odata_stock_wh_field'] . " eq guid'" . $o['odata_warehouse_guid'] . "'" : '';
				if ( $acc_mode && ! isset( $s['acc'] ) ) {
					$r = $this->resolve_accounts( $s );
					if ( is_wp_error( $r ) ) {
						return $r;
					}
				}
				if ( $acc_mode && ! empty( $s['acc'] ) && empty( $s['nofilter'] ) ) {
					$parts = array();
					foreach ( $s['acc'] as $a_guid ) {
						$parts[] = "Account_Key eq guid'" . $a_guid . "'";
					}
					$filter = implode( ' or ', $parts );
				}
			} else {
				$stage  = 'price';
				$path   = $o['odata_price_entity'];
				$item   = $o['odata_price_item'];
				$field  = $o['odata_price_field'];
				$filter = ''; // Тип цен и актуальность отбираем в PHP: в регистре строки вложены в RecordSet.
			}
			$top    = (int) $o['odata_page_size'];
			$select = '';
			// Регистр сведений, подчинённый регистратору: у него есть плоская таблица записей «…_RecordType».
			// В ней сервер сам отбирает нужный тип цен и отдаёт только нужные поля — в разы меньше данных,
			// чем документы установки цен со всей историей и всеми типами.
			$flat = 'price' === $stage && empty( $s['price_nested'] ) && 0 === strpos( $path, 'InformationRegister_' ) && false === strpos( $path, '/' )
				&& '_RecordType' !== substr( $path, -11 ) && '' !== $o['odata_price_type_guid'] && '' !== trim( (string) $o['odata_price_type_field'] );
			if ( $flat ) {
				$path  .= '_RecordType';
				$filter = $o['odata_price_type_field'] . " eq guid'" . $o['odata_price_type_guid'] . "'";
				$pfs    = trim( (string) $o['odata_price_period_field'] );
				$select = ( '' !== $pfs ? $pfs . ',' : '' ) . 'Active,' . $o['odata_price_type_field'] . ',' . $item . ',' . $field;
				$top    = max( $top, self::PRICE_PAGE );
			}
			if ( $acc_mode && empty( $s['stock_noselect'] ) ) {
				$select = 'Account_Key,ExtDimension1,ExtDimension1_Type,ExtDimension2,ExtDimension2_Type,ExtDimension3,ExtDimension3_Type,' . $field;
				$top    = max( $top, self::STOCK_PAGE );
			}
			$rows = $this->page( $path, $s['skip'], $filter, $top, $flat ? $item . ( '' !== $pfs ? ',' . $pfs : '' ) : '', $select, $acc_mode || $flat );
			if ( is_wp_error( $rows ) ) {
				if ( $flat && 0 === (int) $s['skip'] && self::rejected( $rows ) ) {
					$s['price_nested'] = 1; // Плоской таблицы нет или отбор не принят — читаем регистр по-старому, документами.
					continue;
				}
				// Упрощаем запрос только на первой странице и только если сервер отклонил сам запрос:
				// смена набора посреди чтения (тот же $skip по другому набору) исказила бы остатки.
				if ( $acc_mode && 0 === (int) $s['skip'] && self::rejected( $rows ) ) {
					if ( '' !== $select ) {
						$s['stock_noselect'] = 1; // Сервер не принял $select — читаем строки целиком, обычными страницами.
						continue;
					}
					if ( '' !== $filter && empty( $s['nofilter'] ) ) {
						$s['nofilter'] = 1; // Сервер не принял отбор по счёту — читаем без него и отбираем в PHP.
						continue;
					}
				}
				return $rows;
			}
			if ( ( $acc_mode || $flat ) && ! $this->consistent( $s, count( $rows ), count( $rows ) < $top ) ) {
				$r = $this->reread( $state, $s, $stage );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
				continue;
			}
			$pf = trim( (string) $o['odata_price_period_field'] );
			foreach ( $rows as $row ) {
				foreach ( self::records( $row ) as $rec ) {
					if ( $acc_mode ) {
						// Регистр бухгалтерии: номенклатура и склад — среди субконто, остаток — по выбранным счетам.
						$g  = '';
						$wh = '';
						for ( $i = 1; $i <= 3; $i++ ) {
							$t   = isset( $rec[ 'ExtDimension' . $i . '_Type' ] ) ? (string) $rec[ 'ExtDimension' . $i . '_Type' ] : '';
							$val = isset( $rec[ 'ExtDimension' . $i ] ) ? FSYNC_Util::guid( $rec[ 'ExtDimension' . $i ] ) : '';
							if ( false !== strpos( $t, 'Catalog_Номенклатура' ) ) {
								$g = $val;
							} elseif ( false !== strpos( $t, 'Catalog_Склады' ) ) {
								$wh = $val;
							}
						}
						if ( ! empty( $s['acc'] ) && ! in_array( FSYNC_Util::guid( isset( $rec['Account_Key'] ) ? $rec['Account_Key'] : '' ), $s['acc'], true ) ) {
							continue;
						}
						if ( '' !== $o['odata_warehouse_guid'] && $wh !== $o['odata_warehouse_guid'] ) {
							continue;
						}
					} else {
						$g = FSYNC_Util::guid( isset( $rec[ $item ] ) ? $rec[ $item ] : '' );
					}
					if ( '' === $g || FSYNC_Util::EMPTY_GUID === $g || ! isset( $rec[ $field ] ) ) {
						continue;
					}
					$v = FSYNC_Util::num( $rec[ $field ] );
					if ( null === $v ) {
						continue;
					}
					if ( 'stock' === $stage ) {
						if ( $acc_mode ) {
							$ak = FSYNC_Util::guid( isset( $rec['Account_Key'] ) ? $rec['Account_Key'] : '' );
							if ( ! isset( $s['acc_stats'][ $ak ] ) ) {
								$s['acc_stats'][ $ak ] = array( 0, 0 );
							}
							++$s['acc_stats'][ $ak ][0];
							$s['acc_stats'][ $ak ][1] += $v;
						}
						$prev                           = isset( $state['items'][ $g ]['stock'] ) ? $state['items'][ $g ]['stock'] : 0;
						$state['items'][ $g ]['stock'] = $prev + $v;
						continue;
					}
					// Цены: пропускаем неактивные записи и чужие типы цен, из остальных берём самую свежую по периоду.
					if ( ! empty( $o['flag_enabled'] ) && ! isset( $state['items'][ $g ] ) ) {
						continue; // Позиция не прошла отбор по реквизиту — её цена не нужна.
					}
					if ( isset( $rec['Active'] ) && false === $rec['Active'] ) {
						continue;
					}
					if ( '' !== $o['odata_price_type_guid'] && FSYNC_Util::guid( isset( $rec[ $o['odata_price_type_field'] ] ) ? $rec[ $o['odata_price_type_field'] ] : '' ) !== $o['odata_price_type_guid'] ) {
						continue;
					}
					$pp = ( '' !== $pf && isset( $rec[ $pf ] ) ) ? (string) $rec[ $pf ] : '';
					if ( ! isset( $state['items'][ $g ]['pp'] ) || $pp >= $state['items'][ $g ]['pp'] ) {
						$state['items'][ $g ]['price'] = $v;
						$state['items'][ $g ]['pp']    = $pp;
					}
				}
			}
			$sig = md5( wp_json_encode( $rows ) );
			if ( $rows && isset( $s['sig'] ) && $s['sig'] === $sig && $s['skip'] > 0 ) {
				return new WP_Error( 'fsync', 'OData: сервер повторяет одну и ту же страницу ($skip не поддерживается?). Загрузка остановлена.' );
			}
			$s['sig']   = $sig;
			$s['skip'] += count( $rows );
			++$s['pages'];
			if ( count( $rows ) < $top ) {
				++$s['i'];
				$s['skip'] = 0;
				unset( $s['sig'], $s['count'], $s['rows'] );
			}
			if ( $s['pages'] > 300 ) {
				return new WP_Error( 'fsync', 'OData: слишком много страниц (более 300), остановлено.' );
			}
		}
		if ( ! empty( $o['flag_enabled'] ) ) {
			// Отмеченные позиции, для которых в 1С не нашлось ни остатка, ни цены, в выгрузку не идут.
			foreach ( $state['items'] as $g => $it ) {
				if ( ! isset( $it['stock'] ) && ! isset( $it['price'] ) ) {
					unset( $state['items'][ $g ] );
				}
			}
		}
		return true;
	}

	/** Справочник прочитан: оставляем в выгрузке только отмеченные позиции (и только с остатком, если так настроено). */
	private function finish_flags( array &$state ) {
		$o = $this->o;
		if ( empty( $state['flags'] ) ) {
			return new WP_Error( 'fsync', 'Ни у одной номенклатуры не отмечен реквизит «' . $o['flag_property'] . '» (или он не найден в данных). Изменения не вносились.' );
		}
		$state['items'] = array_intersect_key( $state['items'], $state['flags'] );
		if ( ! empty( $o['flag_need_stock'] ) && ! empty( $state['src']['caps']['stock'] ) ) {
			foreach ( $state['items'] as $g => $it ) {
				if ( empty( $it['stock'] ) || $it['stock'] < 1 ) {
					unset( $state['items'][ $g ] );
				}
			}
			$state['notes'][] = sprintf( 'Отбор: реквизит «%s» отмечен у %d позиций, из них с остатком в 1С от 1 шт. — %d (они идут в синхронизацию). Отмеченных без остатка — %d: у привязанных товаров остаток на сайте станет 0.', $o['flag_property'], count( $state['flags'] ), count( $state['items'] ), count( $state['flags'] ) - count( $state['items'] ) );
		} else {
			$state['notes'][] = sprintf( 'Отбор: реквизит «%s» отмечен у %d позиций; в синхронизацию идут те из них, у которых в 1С есть остаток или цена.', $o['flag_property'], count( $state['flags'] ) );
		}
		return true;
	}

	/** Справочник с $select читается крупными страницами: карточек десятки тысяч, а строка маленькая. */
	const CATALOG_PAGE = 5000;

	/** Одна страница справочника номенклатуры: собираем GUID с отмеченным реквизитом. */
	private function flags_page( array &$state, array &$s ) {
		$o = $this->o;
		$flags = ! empty( $o['flag_enabled'] );
		if ( $flags && ! isset( $s['flag_guids'] ) ) {
			$r = $this->resolve_flag( $s );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
		}
		$select = empty( $s['noselect'] ) ? 'Ref_Key,Code,Description,Артикул,Parent_Key' . ( $flags ? ',' . $o['odata_flag_table'] : '' ) : '';
		$top    = '' !== $select ? max( (int) $o['odata_page_size'], self::CATALOG_PAGE ) : (int) $o['odata_page_size'];
		// Сортировка обязательна: без неё 1С отдаёт страницы справочника с повторами (часть карточек
		// приходит по нескольку раз, остальные не приходят вовсе), хотя общее число строк сходится.
		$rows   = $this->page( $o['odata_catalog_entity'], $s['skip'], 'IsFolder eq false', $top, 'Ref_Key', $select, true );
		if ( is_wp_error( $rows ) ) {
			if ( '' !== $select && 0 === (int) $s['skip'] && self::rejected( $rows ) ) {
				$s['noselect'] = 1; // Сервер не принял $select — читаем справочник целиком.
				return true;
			}
			return $rows;
		}
		if ( ! $this->consistent( $s, count( $rows ), count( $rows ) < $top ) ) {
			return $this->reread( $state, $s, 'flags' );
		}
		foreach ( $rows as $row ) {
			$g = FSYNC_Util::guid( isset( $row['Ref_Key'] ) ? $row['Ref_Key'] : '' );
			if ( '' === $g ) {
				continue;
			}
			if ( isset( $state['seen'][ $g ] ) ) {
				return $this->reread( $state, $s, 'flags' ); // Карточка пришла второй раз — страницы «поехали».
			}
			$state['seen'][ $g ] = 1;
			if ( $flags && ! empty( $row[ $o['odata_flag_table'] ] ) && is_array( $row[ $o['odata_flag_table'] ] ) ) {
				foreach ( $row[ $o['odata_flag_table'] ] as $r ) {
					$k = FSYNC_Util::guid( isset( $r[ $o['odata_flag_key_field'] ] ) ? $r[ $o['odata_flag_key_field'] ] : '' );
					if ( in_array( $k, $s['flag_guids'], true ) && self::truthy( isset( $r[ $o['odata_flag_value_field'] ] ) ? $r[ $o['odata_flag_value_field'] ] : null ) ) {
						$state['flags'][ $g ] = 1;
						// Отмечена, но без остатка: нужна в выгрузке, если остаток не обязателен (цена придёт следующим этапом).
						if ( ! isset( $state['items'][ $g ] ) && ( empty( $o['flag_need_stock'] ) || empty( $s['caps']['stock'] ) ) ) {
							$state['items'][ $g ] = array();
						}
						break;
					}
				}
			}
			if ( isset( $state['items'][ $g ] ) ) {
				// Карточка из справочника: код (= SKU на сайте), название, ISBN (Артикул), группа.
				$state['items'][ $g ]['code']  = isset( $row['Code'] ) ? trim( (string) $row['Code'] ) : '';
				$state['items'][ $g ]['name']  = isset( $row['Description'] ) ? trim( (string) $row['Description'] ) : '';
				$state['items'][ $g ]['isbn']  = FSYNC_Util::isbn( isset( $row['Артикул'] ) ? $row['Артикул'] : '' );
				$state['items'][ $g ]['group'] = FSYNC_Util::guid( isset( $row['Parent_Key'] ) ? $row['Parent_Key'] : '' );
			}
		}
		$s['skip'] += count( $rows );
		++$s['pages'];
		if ( count( $rows ) < $top ) {
			++$s['i'];
			$s['skip'] = 0;
			unset( $s['count'], $s['rows'], $state['seen'] );
			if ( $flags ) {
				$r = $this->finish_flags( $state );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
			}
		}
		if ( $s['pages'] > 300 ) {
			return new WP_Error( 'fsync', 'OData: слишком много страниц (более 300), остановлено.' );
		}
		return true;
	}

	private static function truthy( $v ) {
		return true === $v || 1 === $v || '1' === $v || ( is_string( $v ) && 'true' === strtolower( trim( $v ) ) );
	}

	/** Имя реквизита → GUID свойства (по справочнику «Дополнительные реквизиты и сведения»). */
	private function resolve_flag( array &$s ) {
		$o    = $this->o;
		$name = trim( (string) $o['flag_property'] );
		$g    = FSYNC_Util::guid( $name );
		if ( FSYNC_Util::is_guid( $g ) ) {
			$s['flag_guids'] = array( $g );
			return true;
		}
		$rows = $this->page( $o['odata_flag_pvc'], 0, '', 2000 );
		if ( is_wp_error( $rows ) ) {
			return new WP_Error( 'fsync', 'Не удалось прочитать список реквизитов (' . $o['odata_flag_pvc'] . '): ' . $rows->get_error_message() . ' Добавьте «Дополнительные реквизиты и сведения» в состав OData или укажите GUID реквизита.' );
		}
		$want = mb_strtolower( $name );
		$ids  = array();
		foreach ( $rows as $r ) {
			foreach ( array( 'Description', 'Заголовок' ) as $f ) {
				if ( isset( $r[ $f ] ) && mb_strtolower( trim( (string) $r[ $f ] ) ) === $want && ! empty( $r['Ref_Key'] ) ) {
					$ids[] = FSYNC_Util::guid( $r['Ref_Key'] );
					break;
				}
			}
		}
		if ( ! $ids ) {
			return new WP_Error( 'fsync', 'Реквизит «' . $name . '» не найден среди дополнительных реквизитов (' . $o['odata_flag_pvc'] . ').' );
		}
		$s['flag_guids'] = array_values( array_unique( $ids ) );
		return true;
	}

	/** Коды счетов (41.01) превращаются в GUID по плану счетов; GUID принимаются как есть. */
	private function resolve_accounts( array &$s ) {
		$guids = array();
		$codes = array();
		foreach ( array_filter( array_map( 'trim', explode( ',', (string) $this->o['odata_stock_accounts'] ) ) ) as $t ) {
			$g = FSYNC_Util::guid( $t );
			if ( FSYNC_Util::is_guid( $g ) ) {
				$guids[] = $g;
			} else {
				$codes[ $t ] = true;
			}
		}
		if ( $codes ) {
			$rows = $this->page( $this->o['odata_chart_entity'], 0, '', 2000 );
			if ( is_wp_error( $rows ) ) {
				return new WP_Error( 'fsync', 'Не удалось прочитать план счетов (' . $this->o['odata_chart_entity'] . '): ' . $rows->get_error_message() . ' Добавьте план счетов «Хозрасчетный» в состав OData или укажите счета GUID-ами.' );
			}
			foreach ( $rows as $r ) {
				$c = isset( $r['Code'] ) ? trim( (string) $r['Code'] ) : '';
				if ( isset( $codes[ $c ] ) && ! empty( $r['Ref_Key'] ) ) {
					$guids[]                                   = FSYNC_Util::guid( $r['Ref_Key'] );
					$s['acc_names'][ FSYNC_Util::guid( $r['Ref_Key'] ) ] = $c;
					unset( $codes[ $c ] );
				}
			}
			if ( $codes ) {
				return new WP_Error( 'fsync', 'Счета не найдены в плане счетов: ' . implode( ', ', array_keys( $codes ) ) );
			}
		}
		$s['acc'] = array_values( array_unique( $guids ) );
		return true;
	}

	/** Регистры, подчинённые регистратору, приходят как {Recorder, RecordSet:[записи]}; виртуальные таблицы — плоскими строками. */
	private static function records( $row ) {
		if ( is_array( $row ) && isset( $row['RecordSet'] ) && is_array( $row['RecordSet'] ) ) {
			return $row['RecordSet'];
		}
		return array( $row );
	}

	/** Данные одной номенклатуры (для создания черновика). */
	public function details( $guid ) {
		$j = $this->get_json( $this->url( $this->o['odata_catalog_entity'], "(guid'" . $guid . "')", '?$format=json' ) );
		if ( is_wp_error( $j ) ) {
			return $j;
		}
		return array(
			'name'  => isset( $j['Description'] ) ? trim( (string) $j['Description'] ) : '',
			'code'  => isset( $j['Code'] ) ? trim( (string) $j['Code'] ) : '',
			'isbn'  => FSYNC_Util::isbn( isset( $j['Артикул'] ) ? $j['Артикул'] : '' ),
			'group' => FSYNC_Util::guid( isset( $j['Parent_Key'] ) ? $j['Parent_Key'] : '' ),
		);
	}

	/** Проверка подключения: возвращает строки отчёта. */
	public function diagnose() {
		$o = $this->o;
		if ( '' === trim( $o['odata_base'] ) ) {
			return array( 'Не указан адрес OData.' );
		}
		$out  = array();
		$root = $this->get_json( $this->url( '', '', '?$format=json' ) );
		if ( is_wp_error( $root ) ) {
			return array( '✘ Подключение: ' . $root->get_error_message() );
		}
		$out[]  = '✔ Подключение работает.';
		$names  = array();
		if ( ! empty( $root['value'] ) && is_array( $root['value'] ) ) {
			foreach ( $root['value'] as $v ) {
				if ( isset( $v['name'] ) ) {
					$names[] = $v['name'];
				}
			}
		}
		$out[] = 'Сущностей в сервисе: ' . count( $names );

		// Все регистры накопления (без служебных _RecordType): вероятные кандидаты на остатки отмечены ★.
		$regs = array();
		foreach ( $names as $n ) {
			if ( 0 === strpos( $n, 'AccumulationRegister_' ) && '_RecordType' !== substr( $n, -11 ) && false === strpos( substr( $n, 21 ), '_' ) ) {
				$regs[] = $n;
			}
		}
		$cands = array();
		foreach ( $regs as $n ) {
			foreach ( array( 'Склад', 'Партии', 'ТоварыНа', 'Остатк' ) as $needle ) {
				if ( false !== mb_stripos( $n, $needle ) ) {
					$cands[] = $n;
					break;
				}
			}
		}

		$stock_base = explode( '/', $o['odata_stock_entity'] );
		$stock_base = $stock_base[0];
		$out[]      = '';
		if ( in_array( $stock_base, $names, true ) ) {
			$out[] = "✔ Остатки: сущность {$stock_base} найдена.";
		} else {
			$out[] = "✘ Остатки: сущность {$stock_base} НЕ найдена (её нет в составе OData или она называется иначе).";
		}
		$out[] = 'Регистры накопления, доступные в OData (' . count( $regs ) . ', ★ — вероятные кандидаты на остатки):';
		foreach ( $regs as $n ) {
			$out[] = '    ' . ( in_array( $n, $cands, true ) ? '★ ' : '  ' ) . $n;
		}
		foreach ( array_slice( $cands, 0, 4 ) as $n ) {
			$rows  = $this->page( $n . '/Balance()', 0, '', 1 );
			$out[] = '';
			$out[] = 'Проба ' . $n . '/Balance():';
			$out[] = is_wp_error( $rows ) ? '    ✘ ' . $rows->get_error_message() : wp_json_encode( $rows, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
		}

		$price_base = explode( '/', $o['odata_price_entity'] );
		$price_base = $price_base[0];
		$out[]      = '';
		$out[]      = in_array( $price_base, $names, true ) ? "✔ Цены: сущность {$price_base} найдена." : "✘ Цены: сущность {$price_base} НЕ найдена.";
		$cat_base   = explode( '/', $o['odata_catalog_entity'] );
		$out[]      = in_array( $cat_base[0], $names, true ) ? "✔ Номенклатура: сущность {$cat_base[0]} найдена." : "✘ Номенклатура: сущность {$cat_base[0]} НЕ найдена.";

		$rows  = $this->page( $o['odata_price_entity'], 0, '', 1 );
		$out[] = '';
		$out[] = 'Пример данных цен (' . $o['odata_price_entity'] . '):';
		$out[] = is_wp_error( $rows ) ? '    ✘ ' . $rows->get_error_message() : wp_json_encode( $rows, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );

		// Бухгалтерские регистры: в Бухгалтерии остатки товаров могут храниться в регистре «Хозрасчетный».
		$acc = array();
		foreach ( $names as $n ) {
			if ( 0 === strpos( $n, 'AccountingRegister_' ) && false === strpos( substr( $n, 19 ), '_' ) ) {
				$acc[] = $n;
			}
		}
		$out[] = '';
		$out[] = 'Регистры бухгалтерии в OData: ' . ( $acc ? implode( ', ', $acc ) : 'нет (добавьте «Хозрасчетный» в состав OData)' );
		if ( in_array( 'AccountingRegister_Хозрасчетный', $names, true ) ) {
			// Счета 41* из плана счетов.
			$codes = array();
			$chart = $this->page( $o['odata_chart_entity'], 0, '', 2000 );
			$out[] = '';
			if ( is_wp_error( $chart ) ) {
				$out[] = '✘ План счетов (' . $o['odata_chart_entity'] . '): ' . $chart->get_error_message();
			} else {
				$out[] = 'Счета 41* и 004* в плане счетов (код — наименование — Ref_Key):';
				foreach ( $chart as $r ) {
					$c = isset( $r['Code'] ) ? (string) $r['Code'] : '';
					if ( isset( $r['Ref_Key'] ) ) {
						$codes[ FSYNC_Util::guid( $r['Ref_Key'] ) ] = $c;
					}
					if ( 0 === strpos( $c, '41' ) || 0 === strpos( $c, '004' ) ) {
						$out[] = '    ' . $c . ' — ' . ( isset( $r['Description'] ) ? $r['Description'] : '' ) . ' — ' . ( isset( $r['Ref_Key'] ) ? $r['Ref_Key'] : '' );
					}
				}
			}
			// Какие счета содержат строки с номенклатурой (по первым страницам баланса).
			$groups = array();
			$total  = 0;
			$more   = false;
			for ( $pg = 0; $pg < 5; $pg++ ) {
				$rows = $this->page( 'AccountingRegister_Хозрасчетный/Balance()', $pg * (int) $o['odata_page_size'], '' );
				if ( is_wp_error( $rows ) ) {
					$out[] = '✘ Balance(): ' . $rows->get_error_message();
					break;
				}
				foreach ( $rows as $r ) {
					++$total;
					for ( $i = 1; $i <= 3; $i++ ) {
						if ( isset( $r[ 'ExtDimension' . $i . '_Type' ] ) && false !== strpos( (string) $r[ 'ExtDimension' . $i . '_Type' ], 'Catalog_Номенклатура' ) ) {
							$a = FSYNC_Util::guid( isset( $r['Account_Key'] ) ? $r['Account_Key'] : '' );
							if ( ! isset( $groups[ $a ] ) ) {
								$groups[ $a ] = array( 0, 0.0 );
							}
							++$groups[ $a ][0];
							$groups[ $a ][1] += isset( $r['КоличествоBalance'] ) ? (float) $r['КоличествоBalance'] : 0;
							break;
						}
					}
				}
				if ( count( $rows ) < (int) $o['odata_page_size'] ) {
					break;
				}
				$more = ( 4 === $pg );
			}
			$out[] = '';
			$out[] = 'Счета со строками по номенклатуре (просмотрено строк баланса: ' . $total . ( $more ? ', это лишь начало' : '' ) . '): счёт — строк — сумма количества';
			if ( ! $groups ) {
				$out[] = '    (не найдено)';
			}
			foreach ( $groups as $a => $v ) {
				$out[] = '    ' . ( isset( $codes[ $a ] ) ? $codes[ $a ] : '?' ) . ' (' . $a . ') — ' . $v[0] . ' — ' . $v[1];
			}
		}

		// Реквизит-признак «Выгружать на сайт».
		$out[] = '';
		if ( ! in_array( $o['odata_flag_pvc'], $names, true ) ) {
			$out[] = '✘ Список реквизитов (' . $o['odata_flag_pvc'] . ') не найден в OData: добавьте «Дополнительные реквизиты и сведения» в состав.';
		} else {
			$props = $this->page( $o['odata_flag_pvc'], 0, '', 2000 );
			if ( is_wp_error( $props ) ) {
				$out[] = '✘ Реквизиты: ' . $props->get_error_message();
			} else {
				$out[] = 'Реквизиты, в названии которых есть «сайт» (Ref_Key — наименование):';
				$any   = false;
				foreach ( $props as $r ) {
					$t = ( isset( $r['Description'] ) ? $r['Description'] : '' ) . ' ' . ( isset( $r['Заголовок'] ) ? $r['Заголовок'] : '' );
					if ( false !== mb_stripos( $t, 'сайт' ) ) {
						$any   = true;
						$out[] = '    ' . ( isset( $r['Ref_Key'] ) ? $r['Ref_Key'] : '?' ) . ' — ' . trim( $t );
					}
				}
				if ( ! $any ) {
					$out[] = '    (не найдено)';
				}
			}
			$rows  = $this->page( $o['odata_catalog_entity'], 0, 'IsFolder eq false', 2, '', 'Ref_Key,' . $o['odata_flag_table'] );
			$out[] = '';
			$out[] = 'Пример номенклатуры с дополнительными реквизитами (' . $o['odata_flag_table'] . '):';
			$out[] = is_wp_error( $rows ) ? '    ✘ ' . $rows->get_error_message() : wp_json_encode( $rows, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
		}

		$types = $this->page( 'Catalog_ТипыЦенНоменклатуры', 0, '', 50 );
		$out[] = '';
		$out[] = 'Типы цен (Ref_Key — Description), нужный GUID вставьте в настройки:';
		if ( is_wp_error( $types ) ) {
			$out[] = '    ✘ ' . $types->get_error_message();
		} else {
			foreach ( $types as $t ) {
				$out[] = '    ' . ( isset( $t['Ref_Key'] ) ? $t['Ref_Key'] : '?' ) . ' — ' . ( isset( $t['Description'] ) ? $t['Description'] : '?' );
			}
		}
		return $out;
	}
}
