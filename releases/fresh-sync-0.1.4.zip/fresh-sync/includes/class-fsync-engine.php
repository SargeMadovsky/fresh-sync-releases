<?php
defined( 'ABSPATH' ) || exit;

/**
 * Ход одного запуска:
 *   fetch  — получить цены/остатки из источника (возобновляется между тиками);
 *   plan   — сравнить с сайтом в памяти, составить очередь изменений;
 *   apply  — записать изменения порциями по времени (пропускается в пробном запуске).
 *
 * Состояние запуска хранится в опции fsync_run, следующий шаг ставится в очередь
 * Action Scheduler (или WP-Cron, если его нет).
 */
class FSYNC_Engine {

	const RUN    = 'fsync_run';
	const STATUS = 'fsync_status';
	const BASELINE = 'fsync_baseline'; // [ sig, pos, time ] — число позиций с остатком в прошлом успешном запуске.
	const LOG_SOURCE = 'fresh-sync';

	public static function init() {
		add_action( 'fsync_tick', array( __CLASS__, 'tick' ) );
		add_action( 'fsync_cron', array( __CLASS__, 'cron' ) );
		// Расписание проверяется только в админке: на витрине это лишний запрос к БД при каждом заходе.
		add_action( 'admin_init', array( __CLASS__, 'ensure_schedule' ), 20 );
	}

	/* ---------------------------------------------------------------- */
	/* Расписание                                                       */
	/* ---------------------------------------------------------------- */

	public static function ensure_schedule() {
		if ( ! function_exists( 'as_schedule_recurring_action' ) || ! function_exists( 'as_has_scheduled_action' ) ) {
			return;
		}
		$o   = FSYNC_Options::get();
		$has = as_has_scheduled_action( 'fsync_cron' );
		if ( (int) $o['interval_minutes'] > 0 && ! $has ) {
			as_schedule_recurring_action( time() + 60, (int) $o['interval_minutes'] * 60, 'fsync_cron', array(), 'fresh-sync' );
		} elseif ( (int) $o['interval_minutes'] <= 0 && $has ) {
			as_unschedule_all_actions( 'fsync_cron' );
		}
	}

	public static function cron() {
		$o = FSYNC_Options::get();
		if ( (int) $o['interval_minutes'] <= 0 ) {
			return;
		}
		// Запуск не закончен (сайт был недоступен, шаг оборвался): продолжаем его с места остановки,
		// а не начинаем заново. Совсем старый запуск (больше 6 часов) бросаем — данные устарели.
		$cur = get_option( self::RUN );
		if ( is_array( $cur ) && isset( $cur['stage'], $cur['started'] ) && in_array( $cur['stage'], array( 'fetch', 'plan', 'apply' ), true )
			&& ( time() - (int) $cur['started'] ) < 21600 ) {
			self::schedule_tick();
			return;
		}
		self::start( false, 'cron' );
	}

	public static function schedule_tick() {
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( 'fsync_tick', array(), 'fresh-sync' );
		} else {
			wp_schedule_single_event( time() + 1, 'fsync_tick' );
		}
	}

	/* ---------------------------------------------------------------- */
	/* Запуск                                                           */
	/* ---------------------------------------------------------------- */

	public static function start( $dry, $by = 'manual' ) {
		$cur = get_option( self::RUN );
		if ( is_array( $cur ) && isset( $cur['stage'], $cur['updated'] )
			&& in_array( $cur['stage'], array( 'fetch', 'plan', 'apply' ), true )
			&& ( time() - (int) $cur['updated'] ) < 900 ) {
			return new WP_Error( 'fsync', 'Предыдущий запуск ещё выполняется.' );
		}
		self::cleanup_files();
		$state = array(
				'id'       => wp_generate_password( 8, false ),
				'token'    => strtolower( wp_generate_password( 24, false ) ),
				'seq'      => 0,
				'dry'      => $dry ? 1 : 0,
				'by'       => 'cron' === $by ? 'cron' : 'manual',
				'stage'    => 'fetch',
				'started'  => time(),
				'updated'  => time(),
				'finished' => 0,
				'items'    => array(),
				'flags'    => array(),
				'src'      => array(),
				'queue'    => array(),
				'pos'      => 0,
				'stats'    => array(),
				'log'      => array(),
				'notes'    => array(),
				'error'    => '',
		);
		self::save( $state );
		self::publish( $state );
		self::wclog( $state, ( $dry ? 'Пробный запуск начат' : 'Синхронизация начата' ) . ' (' . ( 'cron' === $by ? 'по расписанию' : 'вручную' ) . ').' );
		self::schedule_tick();
		return true;
	}

	/* ---------------------------------------------------------------- */
	/* Хранение состояния                                               */
	/* ---------------------------------------------------------------- */

	/** Тяжёлые части состояния (позиции, отметки, очередь) лежат в файле, а не в таблице опций. */
	const HEAVY = array( 'items', 'flags', 'queue', 'seen' );

	private static function dir() {
		if ( ! function_exists( 'wp_upload_dir' ) ) {
			return '';
		}
		$u = wp_upload_dir( null, false );
		return empty( $u['basedir'] ) ? '' : rtrim( $u['basedir'], '/\\' ) . '/fresh-sync';
	}

	private static function file( array $state ) {
		$dir = self::dir();
		if ( '' === $dir || empty( $state['token'] ) || ! preg_match( '/^[a-z0-9]{16,}$/', (string) $state['token'] ) ) {
			return '';
		}
		return $dir . '/run-' . $state['token'] . '.json';
	}

	/** Удаляет файлы данных прошлых запусков (одновременно идёт только один запуск). */
	private static function cleanup_files() {
		$dir = self::dir();
		if ( '' === $dir || ! is_dir( $dir ) ) {
			return;
		}
		foreach ( (array) glob( $dir . '/run-*.json*' ) as $f ) {
			@unlink( $f ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
	}

	/**
	 * Сохраняет состояние. Позиции, отметки и очередь (мегабайты) пишутся в файл в uploads/fresh-sync,
	 * в опции остаётся лёгкая часть. Если файл записать нельзя — всё хранится в опции, как раньше.
	 *
	 * @param bool $heavy false — тяжёлые части не менялись (шаг записи изменений), файл не переписывается.
	 */
	private static function save( array &$state, $heavy = true ) {
		$file = self::file( $state );
		if ( '' !== $file && ( $heavy || empty( $state['in_file'] ) ) ) {
			$state['seq'] = ( isset( $state['seq'] ) ? (int) $state['seq'] : 0 ) + 1;
			$data         = array( 'seq' => $state['seq'] );
			foreach ( self::HEAVY as $k ) {
				$data[ $k ] = isset( $state[ $k ] ) ? $state[ $k ] : array();
			}
			$state['in_file'] = self::write_file( $file, $data ) ? 1 : 0;
		}
		$light = $state;
		if ( ! empty( $light['in_file'] ) ) {
			foreach ( self::HEAVY as $k ) {
				unset( $light[ $k ] );
			}
		}
		update_option( self::RUN, $light, false );
	}

	private static function write_file( $file, array $data ) {
		$dir = dirname( $file );
		if ( ! is_dir( $dir ) ) {
			if ( function_exists( 'wp_mkdir_p' ) ? ! wp_mkdir_p( $dir ) : ! @mkdir( $dir, 0755, true ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				return false;
			}
		}
		// Папка закрыта от просмотра; имя файла содержит случайную строку.
		if ( ! file_exists( $dir . '/index.html' ) ) {
			@file_put_contents( $dir . '/index.html', '' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			@file_put_contents( $dir . '/.htaccess', "<FilesMatch \"^run-.*\\.json(\\.tmp)?$\">\nRequire all denied\n</FilesMatch>\n" ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		$json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR );
		if ( ! is_string( $json ) ) {
			return false;
		}
		$tmp = $file . '.tmp';
		if ( strlen( $json ) !== @file_put_contents( $tmp, $json ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return false;
		}
		if ( ! @rename( $tmp, $file ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return false;
		}
		return true;
	}

	/**
	 * Состояние запуска целиком (опция + файл).
	 *
	 * @return array|WP_Error|false false — запуска нет.
	 */
	private static function load() {
		$state = get_option( self::RUN );
		if ( ! is_array( $state ) ) {
			return false;
		}
		if ( empty( $state['in_file'] ) || ! in_array( $state['stage'], array( 'fetch', 'plan', 'apply' ), true ) ) {
			return $state;
		}
		$file = self::file( $state );
		$data = ( '' !== $file && is_readable( $file ) ) ? json_decode( (string) file_get_contents( $file ), true ) : null;
		// Номер сохранения в файле и в опции должен совпасть: иначе шаг оборвался между двумя записями,
		// и продолжение с этого места задвоило бы остатки.
		if ( ! is_array( $data ) || ! isset( $data['seq'] ) || (int) $data['seq'] !== (int) $state['seq'] ) {
			return new WP_Error( 'fsync', 'Данные запуска потеряны или повреждены (шаг оборвался во время сохранения). Запуск остановлен, изменения этим шагом не вносились — начните новый запуск.' );
		}
		foreach ( self::HEAVY as $k ) {
			$state[ $k ] = isset( $data[ $k ] ) && is_array( $data[ $k ] ) ? $data[ $k ] : array();
		}
		return $state;
	}

	/** Запуск закончен (успешно или с ошибкой): тяжёлые данные больше не нужны. */
	private static function finish( array $state ) {
		$file = self::file( $state );
		if ( '' !== $file && file_exists( $file ) ) {
			@unlink( $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}
		foreach ( self::HEAVY as $k ) {
			unset( $state[ $k ] );
		}
		unset( $state['in_file'] );
		$state['updated']  = time();
		$state['finished'] = time();
		self::wclog_summary( $state );
		update_option( self::RUN, $state, false );
		self::publish( $state );
		self::notify( $state );
	}

	/* ---------------------------------------------------------------- */
	/* Уведомление о сбоях автозапуска                                  */
	/* ---------------------------------------------------------------- */

	const FAILS      = 'fsync_fails'; // [ n, error, time ] — сколько автозапусков подряд закончились ошибкой.
	const FAILS_MAIL = 3;             // После стольких сбоев подряд владельцу уходит письмо (один раз).

	private static function notify( array $state ) {
		if ( ! isset( $state['by'], $state['stage'] ) || 'cron' !== $state['by'] || ! empty( $state['dry'] ) ) {
			return;
		}
		if ( 'error' !== $state['stage'] ) {
			if ( false !== get_option( self::FAILS ) ) {
				delete_option( self::FAILS );
			}
			return;
		}
		$f = get_option( self::FAILS );
		$n = ( is_array( $f ) && isset( $f['n'] ) ? (int) $f['n'] : 0 ) + 1;
		update_option( self::FAILS, array( 'n' => $n, 'error' => (string) $state['error'], 'time' => time() ), false );
		if ( self::FAILS_MAIL === $n && function_exists( 'wp_mail' ) ) {
			$to = apply_filters( 'fsync_notify_email', get_option( 'admin_email' ) );
			if ( $to ) {
				wp_mail(
					$to,
					'[' . wp_specialchars_decode( (string) get_option( 'blogname' ), ENT_QUOTES ) . '] Синхронизация с 1С не работает',
					'Автоматическая синхронизация цен и остатков с 1С ' . self::FAILS_MAIL . " раза подряд закончилась ошибкой. Остатки на сайте не обновляются.\n\nПоследняя ошибка:\n" . $state['error'] . "\n\nПодробности: " . admin_url( 'admin.php?page=fresh-sync' ) . "\n\nПисьмо отправляется один раз; после первого успешного запуска счётчик сбрасывается."
				);
			}
		}
	}

	/** Сведения о сбоях автозапуска подряд (для страницы плагина) либо пустой массив. */
	public static function fails() {
		$f = get_option( self::FAILS );
		return is_array( $f ) && ! empty( $f['n'] ) ? $f : array();
	}

	public static function source( array $o ) {
		return 'odata' === $o['source'] ? new FSYNC_Source_OData( $o ) : new FSYNC_Source_CSV( $o );
	}

	public static function tick() {
		if ( get_transient( 'fsync_lock' ) ) {
			return;
		}
		// Замок живёт дольше самого длинного шага (порция + ожидание ответа 1С с повтором), чтобы два шага не шли одновременно.
		$o = FSYNC_Options::get();
		set_transient( 'fsync_lock', 1, (int) $o['batch_seconds'] + 240 );
		try {
			self::step();
		} catch ( \Throwable $e ) {
			self::fail( 'Исключение: ' . $e->getMessage() );
		}
		delete_transient( 'fsync_lock' );
	}

	private static function fail( $msg ) {
		$state = get_option( self::RUN );
		if ( ! is_array( $state ) ) {
			$state = array();
		}
		$state['stage'] = 'error';
		$state['error'] = $msg;
		self::finish( $state );
	}

	/**
	 * Лёгкая копия состояния для страницы настроек: без списков позиций и очереди
	 * (они весят мегабайты), чтобы опрос статуса не нагружал сервер.
	 */
	public static function publish( array $state ) {
		$s            = $state;
		$s['items_n'] = isset( $state['items'] ) ? count( (array) $state['items'] ) : 0;
		$s['queue_n'] = isset( $state['queue'] ) ? count( (array) $state['queue'] ) : 0;
		$s['pages']   = isset( $state['src']['pages'] ) ? (int) $state['src']['pages'] : 0;
		unset( $s['items'], $s['queue'], $s['flags'], $s['seen'], $s['src'] );
		update_option( self::STATUS, $s, false );
	}

	public static function status() {
		$s = get_option( self::STATUS );
		if ( is_array( $s ) ) {
			return $s;
		}
		$r = get_option( self::RUN );
		return is_array( $r ) ? $r : array();
	}

	private static function step() {
		$state = self::load();
		if ( is_wp_error( $state ) ) {
			self::fail( $state->get_error_message() );
			return;
		}
		if ( ! is_array( $state ) || ! in_array( $state['stage'], array( 'fetch', 'plan', 'apply' ), true ) ) {
			return;
		}
		$changed = false; // Менялись ли в этом шаге позиции/очередь (то, что лежит в файле).
		$o       = FSYNC_Options::get();
		@set_time_limit( (int) $o['batch_seconds'] + 60 );
		$deadline = microtime( true ) + (int) $o['batch_seconds'];

		if ( 'fetch' === $state['stage'] ) {
			$changed = true;
			$r       = self::source( $o )->fetch( $state, $deadline );
			if ( is_wp_error( $r ) ) {
				self::fail( $r->get_error_message() );
				return;
			}
			if ( true === $r ) {
				$state['stage'] = 'plan';
			}
		}
		if ( 'plan' === $state['stage'] ) {
			$changed = true;
			$err     = self::plan( $state, $o );
			if ( is_string( $err ) ) {
				self::fail( $err );
				return;
			}
		}
		if ( 'apply' === $state['stage'] ) {
			if ( $changed ) {
				// Очередь только что составлена: сохраняем её до первой записи в товары.
				$state['updated'] = time();
				self::save( $state );
				$changed = false;
			}
			self::apply( $state, $o, $deadline );
		}

		$state['updated'] = time();
		if ( in_array( $state['stage'], array( 'fetch', 'apply' ), true ) ) {
			self::save( $state, $changed ); // На шаге записи позиции и очередь не меняются — файл не переписывается.
			self::publish( $state );
			self::schedule_tick();
		} else {
			self::finish( $state );
		}
	}

	/* ---------------------------------------------------------------- */
	/* Планирование                                                     */
	/* ---------------------------------------------------------------- */

	/**
	 * @return string|null Текст ошибки либо null.
	 */
	public static function plan( array &$state, array $o ) {
		$items = $state['items'];
		if ( ! $items ) {
			return 'Источник не вернул ни одной позиции — изменения не вносились.';
		}
		$caps = isset( $state['src']['caps'] ) ? $state['src']['caps'] : array( 'stock' => true, 'price' => true );
		if ( $o['update_stock'] && empty( $caps['stock'] ) ) {
			$state['notes'][] = 'В источнике нет данных об остатках — остатки не обновляются.';
		}
		if ( $o['update_price'] && empty( $caps['price'] ) ) {
			$state['notes'][] = 'В источнике нет данных о ценах — цены не обновляются.';
		}
		if ( ! empty( $state['src']['acc_stats'] ) ) {
			$lines = array();
			foreach ( $state['src']['acc_stats'] as $ak => $v ) {
				$name    = isset( $state['src']['acc_names'][ $ak ] ) ? $state['src']['acc_names'][ $ak ] : substr( $ak, 0, 8 ) . '…';
				$lines[] = sprintf( 'счёт %s — %d строк, %s шт.', $name, $v[0], rtrim( rtrim( number_format( $v[1], 2, '.', '' ), '0' ), '.' ) );
			}
			$state['notes'][] = 'Остатки, прочитанные из 1С (для сверки с оборотно-сальдовой ведомостью): ' . rtrim( implode( '; ', $lines ), '.' ) . '.';
		}
		$o['update_stock'] = $o['update_stock'] && ! empty( $caps['stock'] );
		$o['update_price'] = $o['update_price'] && ! empty( $caps['price'] );

		// Проверка самой выгрузки: остатки должны прийти и не должны резко «похудеть» относительно прошлого запуска.
		$pos = 0;
		$sig = '';
		if ( $o['update_stock'] ) {
			foreach ( $items as $it ) {
				if ( isset( $it['stock'] ) && $it['stock'] >= 1 ) {
					++$pos;
				}
			}
			if ( 0 === $pos ) {
				return 'В выгрузке нет ни одной позиции с остатком от 1 шт. — похоже, остатки из источника не получены. Изменения не вносились.';
			}
			$sig  = self::baseline_sig( $o );
			$base = get_option( self::BASELINE );
			$thr  = (float) $o['zero_guard_percent'];
			if ( is_array( $base ) && isset( $base['sig'], $base['pos'] ) && $base['sig'] === $sig && $base['pos'] > 0 && $thr < 100
				&& $pos < $base['pos'] * ( 1 - $thr / 100 ) ) {
				return sprintf( 'Защита: позиций с остатком в выгрузке %d, в прошлом успешном запуске было %d (падение больше %d%%). Похоже на неполную выгрузку — изменения не вносились. Если так и должно быть, поставьте «Защита от обнуления» = 100 на один запуск.', $pos, (int) $base['pos'], (int) $thr );
			}
		}

		$site    = self::site_products( $o['guid_meta_key'] );
		$by_guid = array();
		$by_sku  = array();
		$by_isbn = array(); // ISBN → id товара без GUID; -1 — на сайте несколько таких товаров.
		$by_name = array();
		$claimed = array(); // Товары сайта, уже привязанные к позиции 1С в этом запуске.
		$dupes   = 0;
		foreach ( $site as $id => $p ) {
			$g = FSYNC_Util::guid( $p['guid'] );
			if ( '' !== $g ) {
				if ( isset( $by_guid[ $g ] ) ) {
					++$dupes;
				} else {
					$by_guid[ $g ] = $id;
				}
			} else {
				$ib = FSYNC_Util::isbn( $p['isbn'] );
				if ( '' !== $ib ) {
					$by_isbn[ $ib ] = isset( $by_isbn[ $ib ] ) ? -1 : $id;
				}
			}
			if ( '' !== trim( $p['title'] ) ) {
				$by_name[ mb_strtolower( trim( $p['title'] ) ) ] = $id;
			}
			if ( '' !== $p['sku'] && ! isset( $by_sku[ $p['sku'] ] ) ) {
				$by_sku[ $p['sku'] ] = $id;
			}
		}

		$reserved = $o['update_stock'] ? self::reserved( $o['reserve_statuses'] ) : array();
		$st       = array(
			'source_items'  => count( $items ),
			'site_linked'   => count( $by_guid ),
			'to_link'       => 0,
			'to_link_isbn'  => 0,
			'ambiguous'     => 0,
			'name_dupes'    => 0,
			'absent_unflagged' => 0,
			'absent_flagged'   => 0,
			'stock_changes' => 0,
			'price_changes' => 0,
			'no_price'      => 0,
			'zero_price'    => 0,
			'zeroed'        => 0,
			'zero_blocked'  => 0,
			'conflicts'     => 0,
			'site_dupes'    => $dupes,
			'new_candidates' => 0,
			'new_queued'    => 0,
			'applied'       => 0,
			'stock_adjusted' => 0,
			'created'       => 0,
			'errors'        => 0,
		);
		if ( $dupes ) {
			$state['notes'][] = "На сайте есть товары с одинаковым GUID: {$dupes} — используется первый найденный.";
		}

		$queue = array();
		$new   = array();
		foreach ( $items as $g => $it ) {
			$id   = isset( $by_guid[ $g ] ) ? $by_guid[ $g ] : 0;
			$link = false;
			if ( ! $id ) {
				$code = isset( $it['code'] ) ? $it['code'] : '';
				$isbn = isset( $it['isbn'] ) ? $it['isbn'] : '';
				$cand = 0;
				$how  = '';
				if ( $o['link_by_sku'] && '' !== $code && isset( $by_sku[ $code ] ) ) {
					$cand = $by_sku[ $code ];
					$how  = 'SKU';
					if ( '' !== FSYNC_Util::guid( $site[ $cand ]['guid'] ) ) {
						++$st['conflicts'];
						self::log( $state, "Конфликт: SKU {$code} уже привязан к другому GUID ({$site[$cand]['guid']}), в источнике {$g}" );
						continue;
					}
				} elseif ( $o['link_by_sku'] && '' !== $isbn && isset( $by_isbn[ $isbn ] ) ) {
					$cand = $by_isbn[ $isbn ];
					$how  = 'ISBN';
					if ( $cand < 0 ) {
						++$st['ambiguous'];
						self::log( $state, "ISBN {$isbn} (код {$code}) есть у нескольких товаров сайта без GUID — не привязано" );
						continue;
					}
				}
				if ( $cand ) {
					if ( isset( $claimed[ $cand ] ) ) {
						++$st['conflicts'];
						self::log( $state, "Конфликт: товар #{$cand} уже привязан к другой позиции 1С, пропущена {$g} (код {$code})" );
						continue;
					}
					$claimed[ $cand ] = $g;
					$id               = $cand;
					$link             = $how;
					++$st['to_link'];
					'ISBN' === $how && ++$st['to_link_isbn'];
				} else {
					if ( ! empty( $it['stock'] ) && $it['stock'] > 0 ) {
						$nm = isset( $it['name'] ) ? mb_strtolower( trim( $it['name'] ) ) : '';
						if ( '' !== $nm && isset( $by_name[ $nm ] ) ) {
							++$st['name_dupes'];
							self::log( $state, "Не создаётся: на сайте уже есть товар #{$by_name[$nm]} с таким названием («{$it['name']}», код {$code}), но он не привязан по SKU/ISBN" );
						} else {
							$new[] = $g;
						}
					}
					continue;
				}
			}
			if ( $o['update_price'] ) {
				if ( ! isset( $it['price'] ) ) {
					++$st['no_price'];
					self::log( $state, self::label( $site[ $id ], $id ) . ': в 1С нет цены выбранного типа — цена на сайте не меняется', 'full' );
				} elseif ( $it['price'] <= 0 && $o['skip_zero_price'] ) {
					++$st['zero_price'];
					self::log( $state, self::label( $site[ $id ], $id ) . ': цена в 1С нулевая — пропущена', 'full' );
				}
			}
			$ch = self::diff( $site[ $id ], $it, $o, isset( $reserved[ $id ] ) ? $reserved[ $id ] : 0 );
			if ( $ch || $link ) {
				$queue[] = array(
					'k'    => 'u',
					'id'   => $id,
					'g'    => $g,
					'link' => $link ? 1 : 0,
					'lm'   => $link ? $link : '',
					's'    => isset( $ch['stock'] ) ? $ch['stock'] : null,
					'o'    => self::cur_stock( $site[ $id ] ),
					'p'    => isset( $ch['price'] ) ? $ch['price'] : null,
				);
				isset( $ch['stock'] ) && ++$st['stock_changes'];
				isset( $ch['price'] ) && ++$st['price_changes'];
				self::log( $state, self::describe( $site[ $id ], $ch, $link, $id ) );
			}
		}

		// Товары сайта с GUID, которых нет в источнике: считаем остаток нулевым.
		// Отмеченные в 1С, но без остатка (распроданы) обнуляются всегда — это штатная работа обмена.
		// Остальные (реквизит не отмечен либо позиции нет в выгрузке вовсе) — только под защитой по доле.
		if ( $o['update_stock'] && $o['absent_is_zero'] ) {
			$oz                 = $o;
			$oz['update_price'] = false;
			$zero               = array();
			$flag_mode          = 'odata' === $o['source'] && ! empty( $o['flag_enabled'] );
			foreach ( $by_guid as $g => $id ) {
				if ( isset( $items[ $g ] ) ) {
					continue;
				}
				$ch = self::diff( $site[ $id ], array( 'stock' => 0 ), $oz, 0 );
				if ( ! isset( $ch['stock'] ) ) {
					continue;
				}
				if ( $flag_mode && isset( $state['flags'][ $g ] ) ) {
					$queue[] = array( 'k' => 'u', 'id' => $id, 'g' => $g, 'link' => 0, 's' => $ch['stock'], 'o' => self::cur_stock( $site[ $id ] ), 'p' => null );
					++$st['absent_flagged'];
					++$st['zeroed'];
					self::log( $state, self::describe( $site[ $id ], array( 'stock' => $ch['stock'] ), false, $id ) . ' (отмечен, но остатка в 1С нет)' );
					continue;
				}
				$zero[] = array( $id, $g, $ch['stock'], self::cur_stock( $site[ $id ] ) );
				$flag_mode && ++$st['absent_unflagged'];
			}
			$pct = $by_guid ? count( $zero ) / count( $by_guid ) * 100 : 0;
			if ( $zero && $pct > (float) $o['zero_guard_percent'] ) {
				$st['zero_blocked'] = count( $zero );
				$state['notes'][]   = sprintf(
					'Защита: к обнулению %d из %d привязанных товаров, %s (%.0f%% при пороге %d%%) — их обнуление пропущено. Отметьте их в 1С или увеличьте порог.',
					count( $zero ),
					count( $by_guid ),
					$flag_mode ? 'у которых реквизит «' . $o['flag_property'] . '» не отмечен' : 'которых нет в выгрузке',
					$pct,
					$o['zero_guard_percent']
				);
			} else {
				foreach ( $zero as $z ) {
					$queue[] = array( 'k' => 'u', 'id' => $z[0], 'g' => $z[1], 'link' => 0, 's' => $z[2], 'o' => $z[3], 'p' => null );
					++$st['zeroed'];
					self::log( $state, self::describe( $site[ $z[0] ], array( 'stock' => $z[2] ), false, $z[0] ) . ' (нет в выгрузке)' );
				}
			}
		}

		if ( (int) $o['max_changes'] > 0 && count( $queue ) > (int) $o['max_changes'] ) {
			$state['notes'][] = sprintf( 'Включено ограничение: из %d изменений будет применено %d.', count( $queue ), (int) $o['max_changes'] );
			$queue            = array_slice( $queue, 0, (int) $o['max_changes'] );
		}

		// Новые товары.
		$has_map = '' !== trim( $o['group_map'] );
		$gm      = self::group_map( $o['group_map'] );
		$cand    = array();
		foreach ( $new as $g ) {
			$grp = isset( $items[ $g ]['group'] ) ? $items[ $g ]['group'] : '';
			if ( $has_map && ( '' === $grp || ! isset( $gm[ $grp ] ) ) ) {
				continue;
			}
			$cand[] = $g;
			$it     = $items[ $g ];
			self::log( $state, sprintf( 'Кандидат в черновики: код %s, «%s», остаток %s%s', isset( $it['code'] ) && '' !== $it['code'] ? $it['code'] : '—', isset( $it['name'] ) ? $it['name'] : '', isset( $it['stock'] ) ? $it['stock'] : '—', '' !== $grp ? ', группа ' . $grp : '' ), 'full' );
		}
		$st['new_candidates'] = count( $cand );
		if ( $st['no_price'] ) {
			$state['notes'][] = sprintf( 'У %d товаров, которые есть на сайте, в 1С нет цены выбранного типа — их цена не обновляется. Список — в полном журнале.', $st['no_price'] );
		}
		$keep                 = array();
		if ( $o['create_new'] && ! $state['dry'] ) {
			foreach ( array_slice( $cand, 0, (int) $o['max_new_per_run'] ) as $g ) {
				$queue[]    = array( 'k' => 'n', 'g' => $g );
				$keep[ $g ] = $items[ $g ];
				++$st['new_queued'];
			}
		}

		if ( '' !== $sig ) {
			update_option( self::BASELINE, array( 'sig' => $sig, 'pos' => $pos, 'time' => time() ), false );
		}
		$state['stats']  = $st;
		$state['queue']  = $queue;
		$state['items']  = $keep;
		$state['pos']    = 0;
		$state['stage']  = ( $state['dry'] || ! $queue ) ? 'done' : 'apply';
		return null;
	}

	/** Настройки, от которых зависит состав выгрузки: при их смене сравнение с прошлым запуском не имеет смысла. */
	private static function baseline_sig( array $o ) {
		$keys = array( 'source', 'csv_location', 'odata_base', 'odata_stock_entity', 'odata_stock_accounts', 'odata_warehouse_guid', 'flag_enabled', 'flag_need_stock', 'flag_property' );
		$v    = array();
		foreach ( $keys as $k ) {
			$v[] = isset( $o[ $k ] ) ? (string) $o[ $k ] : '';
		}
		return md5( implode( '|', $v ) );
	}

	/**
	 * Что нужно изменить в товаре. Чистая функция (без обращений к WP).
	 *
	 * @param array $p  Текущее состояние: stock, manage, price.
	 * @param array $it Строка источника: stock?, price?.
	 * @param array $o  Настройки.
	 * @param int   $reserved Количество в незавершённых онлайн-заказах.
	 */
	public static function diff( array $p, array $it, array $o, $reserved = 0 ) {
		$out = array();
		if ( $o['update_stock'] ) {
			$tgt = null;
			if ( array_key_exists( 'stock', $it ) && null !== $it['stock'] ) {
				$tgt = max( 0, (int) floor( $it['stock'] ) - (int) $reserved );
			} elseif ( $o['absent_is_zero'] ) {
				$tgt = 0;
			}
			if ( null !== $tgt ) {
				$cur = ( 'yes' === $p['manage'] && '' !== $p['stock'] ) ? (int) floor( (float) $p['stock'] ) : null;
				if ( $cur !== $tgt ) {
					$out['stock'] = $tgt;
				}
			}
		}
		if ( $o['update_price'] && isset( $it['price'] ) && ( $it['price'] > 0 || ! $o['skip_zero_price'] ) ) {
			$cur = '' === $p['price'] ? null : (float) $p['price'];
			if ( null === $cur || abs( $cur - (float) $it['price'] ) > 0.004 ) {
				$out['price'] = round( (float) $it['price'], 2 );
			}
		}
		return $out;
	}

	private static function describe( array $p, array $ch, $link, $id ) {
		$parts = array();
		if ( isset( $ch['stock'] ) ) {
			$old     = ( 'yes' === $p['manage'] && '' !== $p['stock'] ) ? (string) (int) floor( (float) $p['stock'] ) : 'не учитывался';
			$parts[] = 'остаток ' . $old . ' → ' . $ch['stock'];
		}
		if ( isset( $ch['price'] ) ) {
			$parts[] = 'цена ' . ( '' === $p['price'] ? '—' : $p['price'] ) . ' → ' . $ch['price'];
		}
		if ( $link ) {
			$parts[] = 'привязка GUID по ' . ( is_string( $link ) ? $link : 'SKU' );
		}
		return self::label( $p, $id ) . ': ' . implode( '; ', $parts );
	}

	private static function label( array $p, $id ) {
		return '' !== $p['sku'] ? 'SKU ' . $p['sku'] : '#' . $id;
	}

	/** Остаток товара сайта на момент планирования (null — склад не ведётся). */
	private static function cur_stock( array $p ) {
		return ( 'yes' === $p['manage'] && '' !== $p['stock'] ) ? (int) floor( (float) $p['stock'] ) : null;
	}

	/**
	 * Строка журнала. Полный журнал пишется в журнал WooCommerce (источник fresh-sync),
	 * на странице плагина показываются первые 40 строк (80 — для ошибок).
	 *
	 * @param bool|string $force true — строка важная (ошибка); 'full' — только в полный журнал.
	 */
	private static function log( array &$state, $msg, $force = false ) {
		self::wclog( $state, $msg, true === $force ? 'warning' : 'info' );
		if ( 'full' === $force ) {
			return;
		}
		$n = count( $state['log'] );
		if ( $n < 40 || ( $force && $n < 80 ) ) {
			$state['log'][] = $msg;
		}
	}

	/** Запись в журнал WooCommerce (WooCommerce → Статус → Журналы, источник fresh-sync). */
	private static function wclog( array $state, $msg, $level = 'info' ) {
		if ( ! function_exists( 'wc_get_logger' ) ) {
			return;
		}
		static $logger = null;
		if ( null === $logger ) {
			$logger = wc_get_logger();
		}
		$id = isset( $state['id'] ) ? $state['id'] : '-';
		$logger->log( $level, '[' . $id . ( empty( $state['dry'] ) ? '' : ', пробный' ) . '] ' . $msg, array( 'source' => self::LOG_SOURCE ) );
	}

	/** Итог запуска в полный журнал: ошибка, примечания, счётчики. */
	private static function wclog_summary( array $state ) {
		if ( ! empty( $state['error'] ) ) {
			self::wclog( $state, 'Запуск остановлен с ошибкой: ' . $state['error'], 'error' );
		}
		foreach ( isset( $state['notes'] ) ? (array) $state['notes'] : array() as $n ) {
			self::wclog( $state, 'Примечание: ' . $n, 'notice' );
		}
		if ( ! empty( $state['stats'] ) ) {
			$p = array();
			foreach ( $state['stats'] as $k => $v ) {
				$v && $p[] = $k . '=' . (int) $v;
			}
			self::wclog( $state, 'Итог: ' . implode( ', ', $p ) );
		}
		if ( empty( $state['error'] ) ) {
			self::wclog( $state, 'Запуск завершён за ' . max( 0, time() - (int) ( isset( $state['started'] ) ? $state['started'] : time() ) ) . ' с.' );
		}
	}

	/* ---------------------------------------------------------------- */
	/* Применение                                                       */
	/* ---------------------------------------------------------------- */

	private static function apply( array &$state, array $o, $deadline ) {
		$n   = count( $state['queue'] );
		$src = null;
		while ( $state['pos'] < $n ) {
			if ( microtime( true ) > $deadline ) {
				return;
			}
			$e = $state['queue'][ $state['pos'] ];
			++$state['pos'];
			try {
				if ( 'u' === $e['k'] ) {
					$adj = self::apply_update( $e, $o );
					++$state['stats']['applied'];
					if ( $adj ) {
						$state['stats']['stock_adjusted'] = ( isset( $state['stats']['stock_adjusted'] ) ? (int) $state['stats']['stock_adjusted'] : 0 ) + 1;
						self::log( $state, '#' . $e['id'] . ': ' . $adj, true );
					}
				} else {
					if ( null === $src ) {
						$src = self::source( $o );
					}
					// Шаг мог оборваться после создания товара, но до сохранения позиции очереди: не создаём второй раз.
					$exists = self::product_by_guid( $o['guid_meta_key'], $e['g'] );
					if ( $exists ) {
						self::log( $state, 'Не создаётся повторно: товар #' . $exists . ' с GUID ' . $e['g'] . ' уже есть на сайте', true );
						continue;
					}
					$r = self::apply_new( $e, $state['items'], $o, $src );
					if ( is_wp_error( $r ) ) {
						++$state['stats']['errors'];
						self::log( $state, 'Ошибка создания ' . $e['g'] . ': ' . $r->get_error_message(), true );
					} else {
						++$state['stats']['created'];
					}
					self::save( $state, false ); // Позиция очереди сохраняется после каждого созданного товара.
				}
			} catch ( \Throwable $ex ) {
				++$state['stats']['errors'];
				self::log( $state, 'Ошибка: ' . $ex->getMessage(), true );
			}
		}
		$state['stage'] = 'done';
	}

	private static function apply_update( array $e, array $o ) {
		$p = wc_get_product( $e['id'] );
		if ( ! $p ) {
			throw new \Exception( 'Товар #' . $e['id'] . ' не найден' );
		}
		if ( $e['link'] ) {
			$p->update_meta_data( $o['guid_meta_key'], $e['g'] );
		}
		$note = '';
		if ( null !== $e['s'] ) {
			$s = (int) $e['s'];
			// Сверка перед записью: если с момента планирования остаток на сайте уменьшился (пришёл заказ),
			// уменьшаем и записываемый остаток на столько же, чтобы не «вернуть» проданное. Рост не учитываем —
			// его подхватит следующий запуск.
			$was = isset( $e['o'] ) ? $e['o'] : null;
			if ( null !== $was && $p->get_manage_stock() && null !== $p->get_stock_quantity() ) {
				$now = (int) floor( (float) $p->get_stock_quantity() );
				if ( $now < (int) $was ) {
					$fix  = max( 0, $s - ( (int) $was - $now ) );
					$note = sprintf( 'остаток на сайте изменился во время запуска (%d → %d), записано %d вместо %d', $was, $now, $fix, $s );
					$s    = $fix;
				}
			}
			$p->set_manage_stock( true );
			$p->set_stock_quantity( $s );
		}
		if ( null !== $e['p'] ) {
			$p->set_regular_price( wc_format_decimal( $e['p'] ) );
		}
		$p->save();
		return $note;
	}

	/** ID товара сайта с таким GUID (0 — нет). */
	private static function product_by_guid( $guid_key, $g ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT pm.post_id FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND pm.meta_value = %s AND p.post_type = 'product' AND p.post_status NOT IN ('trash','auto-draft') LIMIT 1", $guid_key, $g ) );
	}

	private static function apply_new( array $e, array $items, array $o, $src ) {
		$g  = $e['g'];
		$it = isset( $items[ $g ] ) ? $items[ $g ] : array();
		if ( empty( $it['name'] ) && method_exists( $src, 'details' ) ) {
			$d = $src->details( $g );
			if ( is_wp_error( $d ) ) {
				return $d;
			}
			$it = array_merge( $it, array_filter( $d, 'strlen' ) );
		}
		if ( empty( $it['name'] ) ) {
			return new WP_Error( 'fsync', 'нет наименования' );
		}
		$p = new WC_Product_Simple();
		$p->set_name( $it['name'] );
		$p->set_status( 'pending' === $o['new_status'] ? 'pending' : 'draft' );
		if ( ! empty( $it['code'] ) ) {
			try {
				$p->set_sku( $it['code'] );
			} catch ( \Exception $x ) {
				unset( $x ); // Дубликат SKU — создаём без него.
			}
		}
		if ( ! empty( $it['isbn'] ) && method_exists( $p, 'set_global_unique_id' ) ) {
			try {
				$p->set_global_unique_id( $it['isbn'] );
			} catch ( \Exception $x ) {
				unset( $x );
			}
		}
		if ( isset( $it['price'] ) && $it['price'] > 0 ) {
			$p->set_regular_price( wc_format_decimal( $it['price'] ) );
		}
		$p->set_manage_stock( true );
		$p->set_stock_quantity( isset( $it['stock'] ) ? max( 0, (int) floor( $it['stock'] ) ) : 0 );
		$gm = self::group_map( $o['group_map'] );
		if ( ! empty( $it['group'] ) && isset( $gm[ $it['group'] ] ) ) {
			$p->set_category_ids( array( $gm[ $it['group'] ] ) );
		}
		$p->update_meta_data( $o['guid_meta_key'], $g );
		$p->save();
		return true;
	}

	/* ---------------------------------------------------------------- */
	/* Данные сайта                                                     */
	/* ---------------------------------------------------------------- */

	/**
	 * Одним запросом: GUID, SKU, остаток, цена, учёт остатков для всех товаров.
	 *
	 * @return array id => [guid, sku, stock, price, manage]
	 */
	private static function site_products( $guid_key ) {
		global $wpdb;
		$fields = array(
			$guid_key         => 'guid',
			'_sku'            => 'sku',
			'_stock'          => 'stock',
			'_regular_price'  => 'price',
			'_manage_stock'   => 'manage',
			'_global_unique_id' => 'isbn', // GTIN/UPC/EAN/ISBN в WooCommerce 9.2+.
		);
		$keys = array_keys( $fields );
		$in   = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql  = $wpdb->prepare( "SELECT pm.post_id, pm.meta_key, pm.meta_value FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.post_type = 'product' AND p.post_status NOT IN ('trash','auto-draft') AND pm.meta_key IN ($in)", $keys );
		$out  = array();
		foreach ( (array) $wpdb->get_results( $sql ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$id = (int) $r->post_id;
			if ( ! isset( $out[ $id ] ) ) {
				$out[ $id ] = array( 'guid' => '', 'sku' => '', 'stock' => '', 'price' => '', 'manage' => '', 'isbn' => '', 'title' => '' );
			}
			$out[ $id ][ $fields[ $r->meta_key ] ] = (string) $r->meta_value;
		}
		// Названия — для защиты от дублей при создании новых товаров.
		$titles = $wpdb->get_results( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status NOT IN ('trash','auto-draft')" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		foreach ( (array) $titles as $t ) {
			$id = (int) $t->ID;
			if ( ! isset( $out[ $id ] ) ) {
				$out[ $id ] = array( 'guid' => '', 'sku' => '', 'stock' => '', 'price' => '', 'manage' => '', 'isbn' => '', 'title' => '' );
			}
			$out[ $id ]['title'] = (string) $t->post_title;
		}
		return $out;
	}

	/** Количество в незавершённых онлайн-заказах: product_id => qty. */
	private static function reserved( array $statuses ) {
		$res = array();
		if ( ! $statuses ) {
			return $res;
		}
		global $wpdb;
		$st = array();
		foreach ( $statuses as $s ) {
			$s = preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $s ) );
			if ( '' !== $s ) {
				$st[] = 0 === strpos( $s, 'wc-' ) ? $s : 'wc-' . $s;
			}
		}
		if ( ! $st || empty( $wpdb->prefix ) ) {
			return $res;
		}
		// Один запрос по позициям заказов вместо загрузки каждого заказа объектом (статусы очищены выше до [a-z0-9_-]).
		$in   = "'" . implode( "','", $st ) . "'";
		$hpos = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		$join = $hpos
			? "INNER JOIN {$wpdb->prefix}wc_orders o ON o.id = oi.order_id AND o.type = 'shop_order' AND o.status IN ($in)"
			: "INNER JOIN {$wpdb->posts} o ON o.ID = oi.order_id AND o.post_type = 'shop_order' AND o.post_status IN ($in)";
		$sql  = "SELECT pid.meta_value AS pid, SUM(qty.meta_value) AS qty
			FROM {$wpdb->prefix}woocommerce_order_items oi $join
			INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta pid ON pid.order_item_id = oi.order_item_id AND pid.meta_key = '_product_id'
			INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta qty ON qty.order_item_id = oi.order_item_id AND qty.meta_key = '_qty'
			WHERE oi.order_item_type = 'line_item'
			GROUP BY pid.meta_value";
		foreach ( (array) $wpdb->get_results( $sql ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			if ( isset( $r->pid ) && (int) $r->pid > 0 ) {
				$res[ (int) $r->pid ] = (int) round( (float) $r->qty );
			}
		}
		return $res;
	}

	/** Строки «GUID группы = slug или ID категории» → [guid => term_id]. */
	private static function group_map( $text ) {
		$map = array();
		foreach ( preg_split( '/\R/', (string) $text ) as $line ) {
			if ( false === strpos( $line, '=' ) ) {
				continue;
			}
			list( $g, $t ) = array_map( 'trim', explode( '=', $line, 2 ) );
			$g             = FSYNC_Util::guid( $g );
			if ( '' === $g || '' === $t ) {
				continue;
			}
			if ( ctype_digit( $t ) ) {
				$map[ $g ] = (int) $t;
			} else {
				$term = get_term_by( 'slug', $t, 'product_cat' );
				if ( $term ) {
					$map[ $g ] = (int) $term->term_id;
				}
			}
		}
		return $map;
	}
}
