<?php
defined( 'ABSPATH' ) || exit;

class FSYNC_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_fsync', array( __CLASS__, 'handle' ) );
		add_action( 'wp_ajax_fsync_status', array( __CLASS__, 'ajax_status' ) );
		add_filter( 'manage_edit-product_columns', array( __CLASS__, 'product_columns' ), 20 );
		add_action( 'manage_product_posts_custom_column', array( __CLASS__, 'product_column' ), 10, 2 );
		add_action( 'restrict_manage_posts', array( __CLASS__, 'product_filter' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'product_filter_query' ) );
	}

	/** Колонка «GUID 1С» в списке товаров WooCommerce. */
	public static function product_columns( $cols ) {
		$out = array();
		foreach ( $cols as $k => $label ) {
			$out[ $k ] = $label;
			if ( 'sku' === $k ) {
				$out['fsync_guid'] = 'GUID 1С';
			}
		}
		if ( ! isset( $out['fsync_guid'] ) ) {
			$out['fsync_guid'] = 'GUID 1С';
		}
		return $out;
	}

	public static function product_column( $column, $post_id ) {
		if ( 'fsync_guid' !== $column ) {
			return;
		}
		$o = FSYNC_Options::get();
		$g = (string) get_post_meta( $post_id, $o['guid_meta_key'], true );
		if ( '' === $g ) {
			echo '<span style="color:#a00" title="Не привязан к 1С">—</span>';
			return;
		}
		echo '<span style="color:#1a7f37;font-weight:700" title="' . esc_attr( $g ) . '">✔</span>';
	}

	/** Выпадающий список «Привязка к 1С» над списком товаров. */
	public static function product_filter() {
		global $typenow;
		if ( 'product' !== $typenow ) {
			return;
		}
		$cur = isset( $_GET['fsync_link'] ) ? sanitize_key( wp_unslash( $_GET['fsync_link'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		echo '<select name="fsync_link"><option value="">Привязка к 1С</option>';
		echo '<option value="linked"' . selected( 'linked', $cur, false ) . '>Привязан к 1С</option>';
		echo '<option value="unlinked"' . selected( 'unlinked', $cur, false ) . '>Не привязан к 1С</option>';
		echo '</select>';
	}

	/**
	 * Фильтр списка: один запрос по индексированному ключу меты, без подсчётов и обходов товаров в PHP.
	 *
	 * @param WP_Query $q
	 */
	public static function product_filter_query( $q ) {
		if ( ! is_admin() || ! $q->is_main_query() || 'product' !== $q->get( 'post_type' ) || empty( $_GET['fsync_link'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$v = sanitize_key( wp_unslash( $_GET['fsync_link'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( 'linked' !== $v && 'unlinked' !== $v ) {
			return;
		}
		$o  = FSYNC_Options::get();
		$mq = (array) $q->get( 'meta_query' );
		$mq[] = array(
			'key'     => $o['guid_meta_key'],
			'compare' => 'linked' === $v ? 'EXISTS' : 'NOT EXISTS',
		);
		$q->set( 'meta_query', $mq );
	}

	public static function menu() {
		add_submenu_page( 'woocommerce', 'Синхронизация с 1С', 'Синхронизация с 1С', 'manage_woocommerce', 'fresh-sync', array( __CLASS__, 'render' ) );
	}

	/* ---------------------------------------------------------------- */
	/* Обработка кнопок                                                 */
	/* ---------------------------------------------------------------- */

	public static function handle() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'Недостаточно прав.' );
		}
		check_admin_referer( 'fsync' );

		$before = FSYNC_Options::get();
		$o      = FSYNC_Options::save( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$do     = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : 'save';
		$msg    = 'Настройки сохранены.' . ( '' !== FSYNC_Options::$notice ? ' ' . FSYNC_Options::$notice : '' );
		$uid    = get_current_user_id();

		switch ( $do ) {
			case 'dry':
			case 'run':
				$r   = FSYNC_Engine::start( 'dry' === $do );
				$msg = is_wp_error( $r ) ? $r->get_error_message() : ( 'dry' === $do ? 'Пробный запуск поставлен в очередь (ничего не изменяет).' : 'Синхронизация поставлена в очередь.' );
				break;
			case 'tick':
				FSYNC_Engine::tick();
				$msg = 'Шаг выполнен.';
				break;
			case 'resume':
				FSYNC_Engine::schedule_tick();
				$msg = 'Продолжение поставлено в очередь.';
				break;
			case 'test':
				$lines = 'odata' === $o['source'] ? ( new FSYNC_Source_OData( $o ) )->diagnose() : array( 'Проверка подключения нужна только для источника OData.' );
				set_transient( 'fsync_test_' . $uid, implode( "\n", $lines ), 300 );
				$msg = 'Проверка выполнена, результат ниже.';
				break;
		}

		if ( (int) $before['interval_minutes'] !== (int) $o['interval_minutes'] && function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( 'fsync_cron' );
		}
		FSYNC_Engine::ensure_schedule();

		set_transient( 'fsync_msg_' . $uid, $msg, 60 );
		wp_safe_redirect( admin_url( 'admin.php?page=fresh-sync' ) );
		exit;
	}

	/* ---------------------------------------------------------------- */
	/* Вывод                                                            */
	/* ---------------------------------------------------------------- */

	private static function row( $label, $html, $hint = '' ) {
		echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>' . $html . ( $hint ? '<p class="description">' . esc_html( $hint ) . '</p>' : '' ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	private static function in( $name, $val, $type = 'text', $width = 40 ) {
		return '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '" style="width:' . (int) $width . 'em" autocomplete="off">';
	}

	private static function cb( $name, $val, $label = '' ) {
		return '<label><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( 1, (int) $val, false ) . '> ' . esc_html( $label ) . '</label>';
	}

	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$uid  = get_current_user_id();
		$o    = FSYNC_Options::get();
		$run  = FSYNC_Engine::status();
		$msg  = get_transient( 'fsync_msg_' . $uid );
		$test = get_transient( 'fsync_test_' . $uid );
		delete_transient( 'fsync_msg_' . $uid );
		delete_transient( 'fsync_test_' . $uid );

		echo '<div class="wrap"><h1>Синхронизация с 1С: цены и остатки</h1>';
		echo '<p class="description">Версия плагина ' . esc_html( FSYNC_VERSION ) . '. Проверка обновлений на GitHub: ' . esc_html( FSYNC_Updater::last_check_text() ) . '</p>';
		if ( $msg ) {
			echo '<div class="notice notice-info"><p>' . esc_html( $msg ) . '</p></div>';
		}
		if ( 'yes' !== get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
			echo '<div class="notice notice-warning"><p>Чтобы товары с нулевым остатком пропадали из каталога, включите «Скрывать товары, которых нет в наличии» (WooCommerce → Настройки → Товары → Склад).</p></div>';
		}
		if ( ! function_exists( 'as_enqueue_async_action' ) ) {
			echo '<div class="notice notice-warning"><p>Action Scheduler не найден — фоновые шаги будут идти через WP-Cron.</p></div>';
		}

		echo '<div id="fsync-status">';
		self::render_status_block();
		echo '</div>';
		self::render_status_script( is_array( $run ) && isset( $run['stage'] ) && in_array( $run['stage'], array( 'fetch', 'plan', 'apply' ), true ) );

		if ( $test ) {
			echo '<h2>Результат проверки OData</h2><pre style="background:#fff;border:1px solid #ccd0d4;padding:12px;overflow:auto;max-height:480px">' . esc_html( $test ) . '</pre>';
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="fsync">';
		wp_nonce_field( 'fsync' );

		echo '<h2>Источник данных</h2><table class="form-table">';
		self::row(
			'Источник',
			'<label><input type="radio" name="source" value="csv"' . checked( 'csv', $o['source'], false ) . '> CSV-файл</label> &nbsp; <label><input type="radio" name="source" value="odata"' . checked( 'odata', $o['source'], false ) . '> OData 1С:Фреш</label>'
		);
		self::row( 'CSV: путь или URL', self::in( 'csv_location', $o['csv_location'], 'text', 60 ), 'Файл внутри wp-content (например, /var/www/site/wp-content/uploads/fresh-sync/export.csv) или http(s)-ссылка. Колонки: ID, Kod, Articul, Naimenovanie, Kategoriya, price, stock.' );
		self::row( 'OData: адрес сервиса', self::in( 'odata_base', $o['odata_base'], 'text', 60 ), 'Например: https://msk1.1cfresh.com/a/ea/ВАШ_НОМЕР/odata/standard.odata. Доступ по OData настраивается в самой базе 1С (форма «Настройки стандартного интерфейса OData»): там же состав объектов и логин с паролем.' );
		self::row( 'OData: логин', self::in( 'odata_user', $o['odata_user'] ) );
		self::row( 'OData: пароль', self::in( 'odata_pass', '', 'password' ), '' !== $o['odata_pass'] ? 'Пароль сохранён. Оставьте поле пустым, чтобы не менять.' : '' );
		self::row( 'OData: тип цен (GUID)', self::in( 'odata_price_type_guid', $o['odata_price_type_guid'], 'text', 45 ), 'Ref_Key типа цен из справочника «Типы цен номенклатуры». Список выводит кнопка «Проверить OData».' );
		self::row( 'OData: склад (GUID)', self::in( 'odata_warehouse_guid', $o['odata_warehouse_guid'], 'text', 45 ), 'Необязательно. Пусто — остаток суммируется по всем складам. Для регистра бухгалтерии — GUID элемента справочника «Склады».' );
		echo '</table>';

		echo '<details><summary><strong>OData: имена сущностей и полей</strong> (менять, только если проверка подключения показала расхождения)</summary><table class="form-table">';
		foreach ( array(
			'odata_stock_entity'     => 'Остатки: сущность',
			'odata_stock_item'       => 'Остатки: поле номенклатуры',
			'odata_stock_field'      => 'Остатки: поле количества',
			'odata_stock_wh_field'   => 'Остатки: поле склада (только для регистров накопления)',
			'odata_stock_accounts'   => 'Остатки: счета (коды или GUID через запятую; для регистра бухгалтерии)',
			'odata_chart_entity'     => 'План счетов: сущность',
			'odata_price_entity'     => 'Цены: сущность',
			'odata_price_item'       => 'Цены: поле номенклатуры',
			'odata_price_field'      => 'Цены: поле цены',
			'odata_price_type_field' => 'Цены: поле типа цен',
			'odata_price_period_field' => 'Цены: поле периода (для сортировки)',
			'odata_catalog_entity'   => 'Номенклатура: сущность',
			'odata_flag_pvc'         => 'Реквизит-признак: сущность со списком реквизитов',
			'odata_flag_table'       => 'Реквизит-признак: табличная часть номенклатуры',
			'odata_flag_key_field'   => 'Реквизит-признак: поле «свойство»',
			'odata_flag_value_field' => 'Реквизит-признак: поле значения',
		) as $k => $label ) {
			self::row( $label, self::in( $k, $o[ $k ], 'text', 50 ) );
		}
		self::row( 'Размер страницы OData', self::in( 'odata_page_size', $o['odata_page_size'], 'number', 8 ) );
		echo '</table></details>';

		echo '<h2>Что обновлять</h2><table class="form-table">';
		self::row( 'Поля', self::cb( 'update_stock', $o['update_stock'], 'Остаток' ) . '<br>' . self::cb( 'update_price', $o['update_price'], 'Цена (обычная)' ) . '<br>' . self::cb( 'skip_zero_price', $o['skip_zero_price'], 'Не менять цену, если в 1С она нулевая или пустая' ), 'Название, описание, атрибуты, категории и картинки плагин не изменяет никогда.' );
		self::row( 'Отбор по реквизиту 1С', self::cb( 'flag_enabled', $o['flag_enabled'], 'Выгружать на сайт только номенклатуру с отмеченным реквизитом' ) . '<br>' . self::in( 'flag_property', $o['flag_property'], 'text', 35 ) . '<br>' . self::cb( 'flag_need_stock', $o['flag_need_stock'], 'Отметка действует, только если остаток в 1С не меньше 1' ), 'Только для OData. В поле — имя реквизита или его GUID. Отмеченные товары создаются и обновляются; у привязанного товара со снятой отметкой остаток обнуляется (если включено «Нет в выгрузке»). Сначала отметьте реквизит у всех нужных товаров, иначе сработает защита от обнуления. Вторая галочка: позиция с остатком меньше 1 считается «нет в выгрузке» — новая не создаётся и не привязывается, у привязанной остаток на сайте становится 0, цена не обновляется.' );
		self::row( 'Мета-поле с GUID', self::in( 'guid_meta_key', $o['guid_meta_key'], 'text', 25 ), 'По умолчанию то же, что использует плагин EDI (_edi_1c_guid).' );
		self::row( 'Привязка по SKU', self::cb( 'link_by_sku', $o['link_by_sku'], 'Если у товара на сайте нет GUID, искать его по SKU = Kod из выгрузки и записывать GUID' ) );
		self::row( 'Нет в выгрузке', self::cb( 'absent_is_zero', $o['absent_is_zero'], 'Привязанные товары, которых нет в выгрузке, считать отсутствующими (остаток 0)' ) );
		self::row( 'Защита от обнуления', self::in( 'zero_guard_percent', $o['zero_guard_percent'], 'number', 6 ) . ' %', 'Порог в процентах, а не по времени. Товар, отмеченный в 1С, но без остатка (распродан), обнуляется всегда. Защита касается остального: 1) привязанные товары (у которых записан GUID 1С), не отмеченные в 1С или отсутствующие в выгрузке, — если их больше этой доли от всех привязанных, их обнуление пропускается; 2) сама выгрузка — если остатки не пришли вовсе или позиций с остатком стало меньше, чем в прошлом успешном запуске, больше чем на эту долю, запуск останавливается без изменений. 100 отключает обе проверки. Подробнее в README, раздел «Защита от обнуления».' );
		self::row( 'Ограничение изменений', self::in( 'max_changes', $o['max_changes'], 'number', 8 ), '0 — без ограничения. Для первых тестов поставьте 20–50.' );

		$boxes = '';
		foreach ( wc_get_order_statuses() as $slug => $label ) {
			$s      = 0 === strpos( $slug, 'wc-' ) ? substr( $slug, 3 ) : $slug;
			$boxes .= '<label style="display:inline-block;margin-right:14px"><input type="checkbox" name="reserve_statuses[]" value="' . esc_attr( $s ) . '"' . checked( in_array( $s, (array) $o['reserve_statuses'], true ), true, false ) . '> ' . esc_html( $label ) . '</label>';
		}
		self::row( 'Резерв под заказы сайта', $boxes, 'Остаток на сайте = остаток в 1С − количество в заказах с этими статусами. Заказ нужно переводить в «Выполнен» после проведения реализации в 1С. Статусы должны совпадать с теми, при которых WooCommerce сам списывает остаток (обычно «Обрабатывается» и «На удержании»).' );
		echo '</table>';

		echo '<h2>Новые товары из 1С</h2><table class="form-table">';
		self::row( 'Создавать черновики', self::cb( 'create_new', $o['create_new'], 'Создавать товары, которых нет на сайте (только с остатком > 0)' ), 'Создаётся простой товар: название, SKU, ISBN, цена, остаток, GUID. Категория — по таблице ниже. Описание, атрибуты и картинки добавляются вручную.' );
		self::row( 'Статус новых', '<select name="new_status"><option value="draft"' . selected( 'draft', $o['new_status'], false ) . '>Черновик</option><option value="pending"' . selected( 'pending', $o['new_status'], false ) . '>На утверждении</option></select>' );
		self::row( 'Не больше за запуск', self::in( 'max_new_per_run', $o['max_new_per_run'], 'number', 8 ) );
		self::row( 'Группы 1С → категории', '<textarea name="group_map" rows="5" style="width:60em" placeholder="GUID-группы-1С = slug-или-ID-категории">' . esc_textarea( $o['group_map'] ) . '</textarea>', 'По одной строке. Если список не пуст, создаются только товары из перечисленных групп (так служебные группы вроде «Букинист» не попадут на сайт).' );
		echo '</table>';

		echo '<h2>Расписание</h2><table class="form-table">';
		self::row( 'Запускать каждые, мин', self::in( 'interval_minutes', $o['interval_minutes'], 'number', 8 ), '0 — только вручную. Автозапуск делает реальные изменения (не пробный запуск).' );
		self::row( 'Секунд на один шаг', self::in( 'batch_seconds', $o['batch_seconds'], 'number', 8 ), 'Длинные запуски выполняются несколькими шагами. Уменьшите, если хостинг обрывает долгие запросы.' );
		echo '</table>';

		echo '<p>';
		echo '<button class="button" name="do" value="save">Сохранить</button> ';
		echo '<button class="button button-primary" name="do" value="dry">Сохранить и сделать пробный запуск</button> ';
		echo '<button class="button" name="do" value="run" onclick="return confirm(\'Запустить реальную синхронизацию? Цены и остатки на сайте будут изменены.\')">Сохранить и запустить синхронизацию</button> ';
		echo '<button class="button" name="do" value="test">Сохранить и проверить OData</button>';
		echo '</p><p>';
		echo '<button class="button" name="do" value="tick">Выполнить шаг сейчас</button> ';
		echo '<button class="button" name="do" value="resume">Продолжить, если запуск завис</button>';
		echo '</p></form></div>';
	}

	/* ---------------------------------------------------------------- */
	/* Живой статус (AJAX)                                              */
	/* ---------------------------------------------------------------- */

	public static function ajax_status() {
		check_ajax_referer( 'fsync_status', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'forbidden', 403 );
		}
		$run    = FSYNC_Engine::status();
		$active = is_array( $run ) && isset( $run['stage'] ) && in_array( $run['stage'], array( 'fetch', 'plan', 'apply' ), true );
		// Запуск застрял без работающей очереди: подталкиваем следующий шаг (не чаще раза в минуту).
		if ( $active && time() - (int) $run['updated'] > 90 && ! get_transient( 'fsync_nudge' ) ) {
			set_transient( 'fsync_nudge', 1, 60 );
			FSYNC_Engine::schedule_tick();
		}
		ob_start();
		self::render_status_block();
		wp_send_json_success(
			array(
				'html'   => ob_get_clean(),
				'active' => $active,
			)
		);
	}

	private static function render_status_script( $active ) {
		?>
<script>
(function(){
	var box=document.getElementById('fsync-status');
	if(!box){return;}
	var url=<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,nonce=<?php echo wp_json_encode( wp_create_nonce( 'fsync_status' ) ); ?>;
	var active=<?php echo $active ? 'true' : 'false'; ?>,busy=false,t0=Date.now();
	function fmt(s){var m=Math.floor(s/60),r=s%60;return m+' мин '+(r<10?'0':'')+r+' с';}
	function count(){
		var el=box.querySelectorAll('.fsync-count'),d=(Date.now()-t0)/1000;
		for(var i=0;i<el.length;i++){
			var left=Math.round(parseFloat(el[i].getAttribute('data-left'))-d);
			el[i].textContent=left>0?fmt(left):'сейчас';
		}
	}
	function next(){setTimeout(poll,active?8000:120000);}
	function poll(){
		if(document.hidden||busy){next();return;}
		busy=true;
		fetch(url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=fsync_status&nonce='+encodeURIComponent(nonce)})
			.then(function(r){return r.json();})
			.then(function(j){if(j&&j.success){box.innerHTML=j.data.html;active=!!j.data.active;t0=Date.now();count();}})
			.catch(function(){})
			.then(function(){busy=false;next();});
	}
	setInterval(count,1000);count();next();
})();
</script>
		<?php
	}

	private static function render_status_block() {
		self::render_schedule();
		self::render_status( FSYNC_Engine::status() );
	}

	/** Блок «Автозапуск»: включён ли, когда следующий запуск, работает ли очередь. */
	private static function render_schedule() {
		$o   = FSYNC_Options::get();
		$int = (int) $o['interval_minutes'];
		echo '<h2>Автозапуск</h2>';
		$fails = FSYNC_Engine::fails();
		if ( $fails ) {
			echo '<div class="notice notice-error inline"><p><strong>Автозапуск не работает: ошибок подряд — ' . (int) $fails['n'] . '.</strong> Остатки на сайте не обновляются. Последняя ошибка (' . esc_html( wp_date( 'd.m.Y H:i', (int) $fails['time'] ) ) . '): ' . esc_html( $fails['error'] ) . '</p><p class="description">После ' . (int) FSYNC_Engine::FAILS_MAIL . ' ошибок подряд на адрес администратора сайта уходит письмо (один раз). Счётчик сбрасывается первым успешным автозапуском.</p></div>';
		}
		if ( $int <= 0 ) {
			echo '<p>Выключен (интервал 0). Запуски — только вручную.</p>';
			return;
		}
		if ( ! function_exists( 'as_next_scheduled_action' ) ) {
			echo '<p><span style="color:#a00">Action Scheduler не найден — автозапуск по расписанию не работает</span> (Action Scheduler входит в WooCommerce; проверьте, что WooCommerce включён). Ручные запуски работают через WP-Cron.</p>';
			return;
		}
		$next = as_next_scheduled_action( 'fsync_cron' );
		echo '<p>Каждые <strong>' . (int) $int . ' мин</strong>. ';
		if ( true === $next ) {
			echo 'Автозапуск выполняется прямо сейчас.</p>';
		} elseif ( false === $next || null === $next ) {
			echo '<span style="color:#a00">Следующий запуск не запланирован.</span> Нажмите «Сохранить» внизу страницы, расписание создастся заново.</p>';
		} else {
			$left = (int) $next - time();
			echo 'Следующий запуск в ' . esc_html( wp_date( 'H:i:s', (int) $next ) ) . ' (через <strong class="fsync-count" data-left="' . (int) $left . '">…</strong>).</p>';
			if ( $left < -300 ) {
				echo '<div class="notice notice-warning inline"><p>Запуск просрочен больше чем на 5 минут: очередь Action Scheduler не отрабатывает. WP-Cron срабатывает только при заходах на сайт; при малой посещаемости настройте серверный cron, который раз в минуту открывает <code>wp-cron.php</code>, либо отметьте задачу вручную в WooCommerce → Состояние → Запланированные действия.</p></div>';
			}
		}
	}

	private static function render_status( $run ) {
		echo '<h2>Последний запуск</h2>';
		if ( ! is_array( $run ) || empty( $run['stage'] ) ) {
			echo '<p>Запусков ещё не было.</p>';
			return;
		}
		$stages = array(
			'fetch' => 'получение данных из источника',
			'plan'  => 'планирование',
			'apply' => 'применение изменений',
			'done'  => 'завершён',
			'error' => 'ошибка',
		);
		$kind   = ! empty( $run['dry'] ) ? 'пробный (ничего не менялось)' : 'реальный';
		$by = ( isset( $run['by'] ) && 'cron' === $run['by'] ) ? ', автозапуск' : '';
		echo '<p><strong>' . esc_html( ucfirst( $kind ) ) . '</strong>' . esc_html( $by ) . ', начат ' . esc_html( wp_date( 'd.m.Y H:i:s', (int) $run['started'] ) ) . ' — ' . esc_html( isset( $stages[ $run['stage'] ] ) ? $stages[ $run['stage'] ] : $run['stage'] );
		if ( ! empty( $run['finished'] ) ) {
			echo ', завершён ' . esc_html( wp_date( 'H:i:s', (int) $run['finished'] ) ) . ' (' . (int) max( 0, $run['finished'] - $run['started'] ) . ' с)';
		}
		$qn = isset( $run['queue_n'] ) ? (int) $run['queue_n'] : 0;
		if ( 'apply' === $run['stage'] && $qn ) {
			echo ' (' . (int) $run['pos'] . ' из ' . $qn . ')';
		}
		if ( 'fetch' === $run['stage'] ) {
			echo ' (прочитано страниц OData: ' . ( isset( $run['pages'] ) ? (int) $run['pages'] : 0 ) . ', позиций: ' . ( isset( $run['items_n'] ) ? (int) $run['items_n'] : 0 ) . ')';
		}
		echo '</p>';
		if ( in_array( $run['stage'], array( 'fetch', 'plan', 'apply' ), true ) ) {
			echo '<p class="description">Последний шаг: ' . esc_html( wp_date( 'H:i:s', (int) $run['updated'] ) ) . '. Статус обновляется сам, страницу перезагружать не нужно.</p>';
			if ( 'apply' === $run['stage'] && $qn ) {
				echo '<progress max="' . $qn . '" value="' . (int) $run['pos'] . '" style="width:320px"></progress>';
			}
			if ( time() - (int) $run['updated'] > 180 ) {
				echo '<div class="notice notice-warning inline"><p>Запуск не двигался больше 3 минут (так бывает, если сайт или компьютер были выключены: WP-Cron продолжает работу при заходе на сайт, обычно через пару минут всё идёт само). Если не идёт, нажмите «Выполнить шаг сейчас» внизу страницы или «Продолжить, если запуск завис». Если не помогает, откройте WooCommerce → Состояние → Запланированные действия и найдите действие fsync_tick.</p></div>';
			}
		}
		if ( ! empty( $run['error'] ) ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html( $run['error'] ) . '</p></div>';
		}
		$labels = array();
		if ( ! empty( $run['stats'] ) ) {
			$labels = array(
				'source_items'   => 'Позиций в выгрузке',
				'site_linked'    => 'Привязано на сайте (есть GUID)',
				'to_link'        => 'Будет привязано (SKU или ISBN)',
				'to_link_isbn'   => '— из них по ISBN',
				'ambiguous'      => 'Неоднозначный ISBN на сайте (пропущено)',
				'name_dupes'     => 'Не создаются: такое название уже есть на сайте',
				'absent_unflagged' => 'Нет в выгрузке: реквизит не отмечен (под защитой)',
				'absent_flagged'   => 'Нет в выгрузке: отмечен, но остатка нет (обнуляется)',
				'stock_changes'  => 'Изменений остатка',
				'price_changes'  => 'Изменений цены',
				'no_price'       => 'Нет цены в 1С (цена не меняется)',
				'zero_price'     => 'Нулевая цена в 1С (пропущена)',
				'zeroed'         => 'Обнулено (нет в выгрузке)',
				'zero_blocked'   => 'Обнуление заблокировано защитой',
				'conflicts'      => 'Конфликтов SKU/GUID',
				'site_dupes'     => 'Дублей GUID на сайте',
				'new_candidates' => 'Новых товаров (кандидатов)',
				'new_queued'     => 'Новых к созданию',
				'applied'        => 'Применено изменений',
				'stock_adjusted' => '— из них остаток поправлен (заказ во время запуска)',
				'created'        => 'Создано товаров',
				'errors'         => 'Ошибок',
			);
		}
		$full = function_exists( 'wc_get_logger' ) ? '<a href="' . esc_url( admin_url( 'admin.php?page=wc-status&tab=logs&source=' . FSYNC_Engine::LOG_SOURCE ) ) . '">Полный журнал</a> (WooCommerce → Статус → Журналы, источник «' . esc_html( FSYNC_Engine::LOG_SOURCE ) . '»): все изменения, конфликты, кандидаты в черновики, товары без цены.' : '';

		// Две колонки: слева примечания и примеры изменений (журнал тянется на высоту таблицы), справа счётчики.
		// На узком экране колонки встают друг под друга.
		echo '<div style="display:flex;flex-wrap:wrap;gap:20px;margin-top:10px">';
		echo '<div style="flex:1 1 420px;min-inline-size:0;display:flex;flex-direction:column">';
		foreach ( (array) $run['notes'] as $n ) {
			echo '<div class="notice notice-warning inline" style="margin:0 0 8px"><p>' . esc_html( $n ) . '</p></div>';
		}
		if ( ! empty( $run['log'] ) ) {
			echo '<h3 style="margin:8px 0 4px">Примеры изменений</h3>';
			if ( '' !== $full ) {
				echo '<p style="margin:0 0 8px">' . $full . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '<pre style="flex:1 1 0;min-block-size:320px;margin:0;background:#fff;border:1px solid #ccd0d4;padding:12px;overflow:auto;overscroll-behavior:contain">' . esc_html( implode( "\n", $run['log'] ) ) . '</pre>';
		} elseif ( '' !== $full && ! empty( $run['stats'] ) ) {
			echo '<p>' . $full . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>';
		if ( $labels ) {
			echo '<div style="flex:0 1 auto"><table class="widefat striped" style="max-width:520px"><tbody>';
			foreach ( $labels as $k => $label ) {
				if ( isset( $run['stats'][ $k ] ) ) {
					echo '<tr><td>' . esc_html( $label ) . '</td><td><strong>' . (int) $run['stats'][ $k ] . '</strong></td></tr>';
				}
			}
			echo '</tbody></table></div>';
		}
		echo '</div>';
	}
}
