<?php
defined( 'ABSPATH' ) || exit;

/**
 * Ход одного запуска:
 *   fetch  — получить цены/остатки из источника (возобновляется между тиками);
 *   plan   — сравнить с сайтом в памяти, составить очередь изменений;
 *   apply  — записать изменения порциями по времени (пропускается в пробном запуске).
 *
 * Состояние запуска хранится в опции fsync_run, следующий шаг ставится в очередь
 * Action Scheduler (или WP-Cron, если его нет).
 */
class FSYNC_Engine {

	const RUN    = 'fsync_run';
	const STATUS = 'fsync_status';

	public static function init() {
		add_action( 'fsync_tick', array( __CLASS__, 'tick' ) );
		add_action( 'fsync_cron', array( __CLASS__, 'cron' ) );
		add_action( 'init', array( __CLASS__, 'ensure_schedule' ), 20 );
	}

	/* ---------------------------------------------------------------- */
	/* Расписание                                                       */
	/* ---------------------------------------------------------------- */

	public static function ensure_schedule() {
		if ( ! function_exists( 'as_schedule_recurring_action' ) || ! function_exists( 'as_has_scheduled_action' ) ) {
			return;
		}
		$o   = FSYNC_Options::get();
		$has = as_has_scheduled_action( 'fsync_cron' );
		if ( (int) $o['interval_minutes'] > 0 && ! $has ) {
			as_schedule_recurring_action( time() + 60, (int) $o['interval_minutes'] * 60, 'fsync_cron', array(), 'fresh-sync' );
		} elseif ( (int) $o['interval_minutes'] <= 0 && $has ) {
			as_unschedule_all_actions( 'fsync_cron' );
		}
	}

	public static function cron() {
		$o = FSYNC_Options::get();
		if ( (int) $o['interval_minutes'] > 0 ) {
			self::start( false, 'cron' );
		}
	}

	public static function schedule_tick() {
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( 'fsync_tick', array(), 'fresh-sync' );
		} else {
			wp_schedule_single_event( time() + 1, 'fsync_tick' );
		}
	}

	/* ---------------------------------------------------------------- */
	/* Запуск                                                           */
	/* ---------------------------------------------------------------- */

	public static function start( $dry, $by = 'manual' ) {
		$cur = get_option( self::RUN );
		if ( is_array( $cur ) && isset( $cur['stage'], $cur['updated'] )
			&& in_array( $cur['stage'], array( 'fetch', 'plan', 'apply' ), true )
			&& ( time() - (int) $cur['updated'] ) < 900 ) {
			return new WP_Error( 'fsync', 'Предыдущий запуск ещё выполняется.' );
		}
		update_option(
			self::RUN,
			array(
				'id'       => wp_generate_password( 8, false ),
				'dry'      => $dry ? 1 : 0,
				'by'       => 'cron' === $by ? 'cron' : 'manual',
				'stage'    => 'fetch',
				'started'  => time(),
				'updated'  => time(),
				'finished' => 0,
				'items'    => array(),
				'flags'    => array(),
				'src'      => array(),
				'queue'    => array(),
				'pos'      => 0,
				'stats'    => array(),
				'log'      => array(),
				'notes'    => array(),
				'error'    => '',
			),
			false
		);
		self::publish( (array) get_option( self::RUN ) );
		self::schedule_tick();
		return true;
	}

	public static function source( array $o ) {
		return 'odata' === $o['source'] ? new FSYNC_Source_OData( $o ) : new FSYNC_Source_CSV( $o );
	}

	public static function tick() {
		if ( get_transient( 'fsync_lock' ) ) {
			return;
		}
		set_transient( 'fsync_lock', 1, 120 );
		try {
			self::step();
		} catch ( \Throwable $e ) {
			self::fail( 'Исключение: ' . $e->getMessage() );
		}
		delete_transient( 'fsync_lock' );
	}

	private static function fail( $msg ) {
		$state = get_option( self::RUN );
		if ( ! is_array( $state ) ) {
			$state = array();
		}
		unset( $state['items'], $state['queue'], $state['flags'] );
		$state['stage']    = 'error';
		$state['error']    = $msg;
		$state['updated']  = time();
		$state['finished'] = time();
		update_option( self::RUN, $state, false );
		self::publish( $state );
	}

	/**
	 * Лёгкая копия состояния для страницы настроек: без списков позиций и очереди
	 * (они весят мегабайты), чтобы опрос статуса не нагружал сервер.
	 */
	public static function publish( array $state ) {
		$s            = $state;
		$s['items_n'] = isset( $state['items'] ) ? count( (array) $state['items'] ) : 0;
		$s['queue_n'] = isset( $state['queue'] ) ? count( (array) $state['queue'] ) : 0;
		$s['pages']   = isset( $state['src']['pages'] ) ? (int) $state['src']['pages'] : 0;
		unset( $s['items'], $s['queue'], $s['flags'], $s['src'] );
		update_option( self::STATUS, $s, false );
	}

	public static function status() {
		$s = get_option( self::STATUS );
		if ( is_array( $s ) ) {
			return $s;
		}
		$r = get_option( self::RUN );
		return is_array( $r ) ? $r : array();
	}

	private static function step() {
		$state = get_option( self::RUN );
		if ( ! is_array( $state ) || ! in_array( $state['stage'], array( 'fetch', 'plan', 'apply' ), true ) ) {
			return;
		}
		$o = FSYNC_Options::get();
		@set_time_limit( (int) $o['batch_seconds'] + 60 );
		$deadline = microtime( true ) + (int) $o['batch_seconds'];

		if ( 'fetch' === $state['stage'] ) {
			$r = self::source( $o )->fetch( $state, $deadline );
			if ( is_wp_error( $r ) ) {
				self::fail( $r->get_error_message() );
				return;
			}
			if ( true === $r ) {
				$state['stage'] = 'plan';
			}
		}
		if ( 'plan' === $state['stage'] ) {
			$err = self::plan( $state, $o );
			if ( is_string( $err ) ) {
				self::fail( $err );
				return;
			}
		}
		if ( 'apply' === $state['stage'] ) {
			self::apply( $state, $o, $deadline );
		}

		$state['updated'] = time();
		if ( in_array( $state['stage'], array( 'fetch', 'apply' ), true ) ) {
			update_option( self::RUN, $state, false );
			self::publish( $state );
			self::schedule_tick();
		} else {
			unset( $state['items'], $state['queue'], $state['flags'] );
			$state['finished'] = time();
			update_option( self::RUN, $state, false );
			self::publish( $state );
		}
	}

	/* ---------------------------------------------------------------- */
	/* Планирование                                                     */
	/* ---------------------------------------------------------------- */

	/**
	 * @return string|null Текст ошибки либо null.
	 */
	public static function plan( array &$state, array $o ) {
		$items = $state['items'];
		if ( ! $items ) {
			return 'Источник не вернул ни одной позиции — изменения не вносились.';
		}
		$caps = isset( $state['src']['caps'] ) ? $state['src']['caps'] : array( 'stock' => true, 'price' => true );
		if ( $o['update_stock'] && empty( $caps['stock'] ) ) {
			$state['notes'][] = 'В источнике нет данных об остатках — остатки не обновляются.';
		}
		if ( $o['update_price'] && empty( $caps['price'] ) ) {
			$state['notes'][] = 'В источнике нет данных о ценах — цены не обновляются.';
		}
		if ( ! empty( $state['src']['acc_stats'] ) ) {
			$lines = array();
			foreach ( $state['src']['acc_stats'] as $ak => $v ) {
				$name    = isset( $state['src']['acc_names'][ $ak ] ) ? $state['src']['acc_names'][ $ak ] : substr( $ak, 0, 8 ) . '…';
				$lines[] = sprintf( 'счёт %s — %d строк, %s шт.', $name, $v[0], rtrim( rtrim( number_format( $v[1], 2, '.', '' ), '0' ), '.' ) );
			}
			$state['notes'][] = 'Остатки, прочитанные из 1С (для сверки с оборотно-сальдовой ведомостью): ' . implode( '; ', $lines ) . '.';
		}
		$o['update_stock'] = $o['update_stock'] && ! empty( $caps['stock'] );
		$o['update_price'] = $o['update_price'] && ! empty( $caps['price'] );

		$site    = self::site_products( $o['guid_meta_key'] );
		$by_guid = array();
		$by_sku  = array();
		$by_isbn = array(); // ISBN → id товара без GUID; -1 — на сайте несколько таких товаров.
		$by_name = array();
		$claimed = array(); // Товары сайта, уже привязанные к позиции 1С в этом запуске.
		$dupes   = 0;
		foreach ( $site as $id => $p ) {
			$g = FSYNC_Util::guid( $p['guid'] );
			if ( '' !== $g ) {
				if ( isset( $by_guid[ $g ] ) ) {
					++$dupes;
				} else {
					$by_guid[ $g ] = $id;
				}
			} else {
				$ib = FSYNC_Util::isbn( $p['isbn'] );
				if ( '' !== $ib ) {
					$by_isbn[ $ib ] = isset( $by_isbn[ $ib ] ) ? -1 : $id;
				}
			}
			if ( '' !== trim( $p['title'] ) ) {
				$by_name[ mb_strtolower( trim( $p['title'] ) ) ] = $id;
			}
			if ( '' !== $p['sku'] && ! isset( $by_sku[ $p['sku'] ] ) ) {
				$by_sku[ $p['sku'] ] = $id;
			}
		}

		$reserved = $o['update_stock'] ? self::reserved( $o['reserve_statuses'] ) : array();
		$st       = array(
			'source_items'  => count( $items ),
			'site_linked'   => count( $by_guid ),
			'to_link'       => 0,
			'to_link_isbn'  => 0,
			'ambiguous'     => 0,
			'name_dupes'    => 0,
			'absent_unflagged' => 0,
			'absent_flagged'   => 0,
			'stock_changes' => 0,
			'price_changes' => 0,
			'zeroed'        => 0,
			'zero_blocked'  => 0,
			'conflicts'     => 0,
			'site_dupes'    => $dupes,
			'new_candidates' => 0,
			'new_queued'    => 0,
			'applied'       => 0,
			'created'       => 0,
			'errors'        => 0,
		);
		if ( $dupes ) {
			$state['notes'][] = "На сайте есть товары с одинаковым GUID: {$dupes} — используется первый найденный.";
		}

		$queue = array();
		$new   = array();
		foreach ( $items as $g => $it ) {
			$id   = isset( $by_guid[ $g ] ) ? $by_guid[ $g ] : 0;
			$link = false;
			if ( ! $id ) {
				$code = isset( $it['code'] ) ? $it['code'] : '';
				$isbn = isset( $it['isbn'] ) ? $it['isbn'] : '';
				$cand = 0;
				$how  = '';
				if ( $o['link_by_sku'] && '' !== $code && isset( $by_sku[ $code ] ) ) {
					$cand = $by_sku[ $code ];
					$how  = 'SKU';
					if ( '' !== FSYNC_Util::guid( $site[ $cand ]['guid'] ) ) {
						++$st['conflicts'];
						self::log( $state, "Конфликт: SKU {$code} уже привязан к другому GUID ({$site[$cand]['guid']}), в источнике {$g}" );
						continue;
					}
				} elseif ( $o['link_by_sku'] && '' !== $isbn && isset( $by_isbn[ $isbn ] ) ) {
					$cand = $by_isbn[ $isbn ];
					$how  = 'ISBN';
					if ( $cand < 0 ) {
						++$st['ambiguous'];
						self::log( $state, "ISBN {$isbn} (код {$code}) есть у нескольких товаров сайта без GUID — не привязано" );
						continue;
					}
				}
				if ( $cand ) {
					if ( isset( $claimed[ $cand ] ) ) {
						++$st['conflicts'];
						self::log( $state, "Конфликт: товар #{$cand} уже привязан к другой позиции 1С, пропущена {$g} (код {$code})" );
						continue;
					}
					$claimed[ $cand ] = $g;
					$id               = $cand;
					$link             = $how;
					++$st['to_link'];
					'ISBN' === $how && ++$st['to_link_isbn'];
				} else {
					if ( ! empty( $it['stock'] ) && $it['stock'] > 0 ) {
						$nm = isset( $it['name'] ) ? mb_strtolower( trim( $it['name'] ) ) : '';
						if ( '' !== $nm && isset( $by_name[ $nm ] ) ) {
							++$st['name_dupes'];
							self::log( $state, "Не создаётся: на сайте уже есть товар #{$by_name[$nm]} с таким названием («{$it['name']}», код {$code}), но он не привязан по SKU/ISBN" );
						} else {
							$new[] = $g;
						}
					}
					continue;
				}
			}
			$ch = self::diff( $site[ $id ], $it, $o, isset( $reserved[ $id ] ) ? $reserved[ $id ] : 0 );
			if ( $ch || $link ) {
				$queue[] = array(
					'k'    => 'u',
					'id'   => $id,
					'g'    => $g,
					'link' => $link ? 1 : 0,
					'lm'   => $link ? $link : '',
					's'    => isset( $ch['stock'] ) ? $ch['stock'] : null,
					'p'    => isset( $ch['price'] ) ? $ch['price'] : null,
				);
				isset( $ch['stock'] ) && ++$st['stock_changes'];
				isset( $ch['price'] ) && ++$st['price_changes'];
				self::log( $state, self::describe( $site[ $id ], $ch, $link, $id ) );
			}
		}

		// Товары сайта с GUID, которых нет в источнике: считаем остаток нулевым (с защитой).
		if ( $o['update_stock'] && $o['absent_is_zero'] ) {
			$oz                 = $o;
			$oz['update_price'] = false;
			$zero               = array();
			foreach ( $by_guid as $g => $id ) {
				if ( isset( $items[ $g ] ) ) {
					continue;
				}
				$ch = self::diff( $site[ $id ], array( 'stock' => 0 ), $oz, 0 );
				if ( isset( $ch['stock'] ) ) {
					$zero[] = array( $id, $g, $ch['stock'] );
					if ( 'odata' === $o['source'] && ! empty( $o['flag_enabled'] ) ) {
						isset( $state['flags'][ $g ] ) ? ++$st['absent_flagged'] : ++$st['absent_unflagged'];
					}
				}
			}
			$pct = $by_guid ? count( $zero ) / count( $by_guid ) * 100 : 0;
			if ( $zero && $pct > (float) $o['zero_guard_percent'] ) {
				$st['zero_blocked'] = count( $zero );
				$state['notes'][]   = sprintf( 'Защита: к обнулению %d из %d привязанных товаров (%.0f%% при пороге %d%%) — обнуление пропущено. Проверьте выгрузку или увеличьте порог.', count( $zero ), count( $by_guid ), $pct, $o['zero_guard_percent'] );
					if ( $st['absent_flagged'] || $st['absent_unflagged'] ) {
						$state['notes'][] = sprintf( 'Из них: реквизит «%s» не отмечен — %d; отмечен, но в 1С нет остатка и цены — %d.', $o['flag_property'], $st['absent_unflagged'], $st['absent_flagged'] );
					}
			} else {
				foreach ( $zero as $z ) {
					$queue[] = array( 'k' => 'u', 'id' => $z[0], 'g' => $z[1], 'link' => 0, 's' => $z[2], 'p' => null );
					++$st['zeroed'];
					self::log( $state, self::describe( $site[ $z[0] ], array( 'stock' => $z[2] ), false, $z[0] ) . ' (нет в выгрузке)' );
				}
			}
		}

		if ( (int) $o['max_changes'] > 0 && count( $queue ) > (int) $o['max_changes'] ) {
			$state['notes'][] = sprintf( 'Включено ограничение: из %d изменений будет применено %d.', count( $queue ), (int) $o['max_changes'] );
			$queue            = array_slice( $queue, 0, (int) $o['max_changes'] );
		}

		// Новые товары.
		$has_map = '' !== trim( $o['group_map'] );
		$gm      = self::group_map( $o['group_map'] );
		$cand    = array();
		foreach ( $new as $g ) {
			$grp = isset( $items[ $g ]['group'] ) ? $items[ $g ]['group'] : '';
			if ( $has_map && ( '' === $grp || ! isset( $gm[ $grp ] ) ) ) {
				continue;
			}
			$cand[] = $g;
		}
		$st['new_candidates'] = count( $cand );
		$keep                 = array();
		if ( $o['create_new'] && ! $state['dry'] ) {
			foreach ( array_slice( $cand, 0, (int) $o['max_new_per_run'] ) as $g ) {
				$queue[]    = array( 'k' => 'n', 'g' => $g );
				$keep[ $g ] = $items[ $g ];
				++$st['new_queued'];
			}
		}

		$state['stats']  = $st;
		$state['queue']  = $queue;
		$state['items']  = $keep;
		$state['pos']    = 0;
		$state['stage']  = ( $state['dry'] || ! $queue ) ? 'done' : 'apply';
		return null;
	}

	/**
	 * Что нужно изменить в товаре. Чистая функция (без обращений к WP).
	 *
	 * @param array $p  Текущее состояние: stock, manage, price.
	 * @param array $it Строка источника: stock?, price?.
	 * @param array $o  Настройки.
	 * @param int   $reserved Количество в незавершённых онлайн-заказах.
	 */
	public static function diff( array $p, array $it, array $o, $reserved = 0 ) {
		$out = array();
		if ( $o['update_stock'] ) {
			$tgt = null;
			if ( array_key_exists( 'stock', $it ) && null !== $it['stock'] ) {
				$tgt = max( 0, (int) floor( $it['stock'] ) - (int) $reserved );
			} elseif ( $o['absent_is_zero'] ) {
				$tgt = 0;
			}
			if ( null !== $tgt ) {
				$cur = ( 'yes' === $p['manage'] && '' !== $p['stock'] ) ? (int) floor( (float) $p['stock'] ) : null;
				if ( $cur !== $tgt ) {
					$out['stock'] = $tgt;
				}
			}
		}
		if ( $o['update_price'] && isset( $it['price'] ) && ( $it['price'] > 0 || ! $o['skip_zero_price'] ) ) {
			$cur = '' === $p['price'] ? null : (float) $p['price'];
			if ( null === $cur || abs( $cur - (float) $it['price'] ) > 0.004 ) {
				$out['price'] = round( (float) $it['price'], 2 );
			}
		}
		return $out;
	}

	private static function describe( array $p, array $ch, $link, $id ) {
		$parts = array();
		if ( isset( $ch['stock'] ) ) {
			$old     = ( 'yes' === $p['manage'] && '' !== $p['stock'] ) ? (string) (int) floor( (float) $p['stock'] ) : 'не учитывался';
			$parts[] = 'остаток ' . $old . ' → ' . $ch['stock'];
		}
		if ( isset( $ch['price'] ) ) {
			$parts[] = 'цена ' . ( '' === $p['price'] ? '—' : $p['price'] ) . ' → ' . $ch['price'];
		}
		if ( $link ) {
			$parts[] = 'привязка GUID по ' . ( is_string( $link ) ? $link : 'SKU' );
		}
		return ( '' !== $p['sku'] ? 'SKU ' . $p['sku'] : '#' . $id ) . ': ' . implode( '; ', $parts );
	}

	private static function log( array &$state, $msg, $force = false ) {
		$n = count( $state['log'] );
		if ( $n < 40 || ( $force && $n < 80 ) ) {
			$state['log'][] = $msg;
		}
	}

	/* ---------------------------------------------------------------- */
	/* Применение                                                       */
	/* ---------------------------------------------------------------- */

	private static function apply( array &$state, array $o, $deadline ) {
		$n   = count( $state['queue'] );
		$src = null;
		while ( $state['pos'] < $n ) {
			if ( microtime( true ) > $deadline ) {
				return;
			}
			$e = $state['queue'][ $state['pos'] ];
			++$state['pos'];
			try {
				if ( 'u' === $e['k'] ) {
					self::apply_update( $e, $o );
					++$state['stats']['applied'];
				} else {
					if ( null === $src ) {
						$src = self::source( $o );
					}
					$r = self::apply_new( $e, $state['items'], $o, $src );
					if ( is_wp_error( $r ) ) {
						++$state['stats']['errors'];
						self::log( $state, 'Ошибка создания ' . $e['g'] . ': ' . $r->get_error_message(), true );
					} else {
						++$state['stats']['created'];
					}
				}
			} catch ( \Throwable $ex ) {
				++$state['stats']['errors'];
				self::log( $state, 'Ошибка: ' . $ex->getMessage(), true );
			}
		}
		$state['stage'] = 'done';
	}

	private static function apply_update( array $e, array $o ) {
		$p = wc_get_product( $e['id'] );
		if ( ! $p ) {
			throw new \Exception( 'Товар #' . $e['id'] . ' не найден' );
		}
		if ( $e['link'] ) {
			$p->update_meta_data( $o['guid_meta_key'], $e['g'] );
		}
		if ( null !== $e['s'] ) {
			$p->set_manage_stock( true );
			$p->set_stock_quantity( $e['s'] );
		}
		if ( null !== $e['p'] ) {
			$p->set_regular_price( wc_format_decimal( $e['p'] ) );
		}
		$p->save();
	}

	private static function apply_new( array $e, array $items, array $o, $src ) {
		$g  = $e['g'];
		$it = isset( $items[ $g ] ) ? $items[ $g ] : array();
		if ( empty( $it['name'] ) && method_exists( $src, 'details' ) ) {
			$d = $src->details( $g );
			if ( is_wp_error( $d ) ) {
				return $d;
			}
			$it = array_merge( $it, array_filter( $d, 'strlen' ) );
		}
		if ( empty( $it['name'] ) ) {
			return new WP_Error( 'fsync', 'нет наименования' );
		}
		$p = new WC_Product_Simple();
		$p->set_name( $it['name'] );
		$p->set_status( 'pending' === $o['new_status'] ? 'pending' : 'draft' );
		if ( ! empty( $it['code'] ) ) {
			try {
				$p->set_sku( $it['code'] );
			} catch ( \Exception $x ) {
				unset( $x ); // Дубликат SKU — создаём без него.
			}
		}
		if ( ! empty( $it['isbn'] ) && method_exists( $p, 'set_global_unique_id' ) ) {
			try {
				$p->set_global_unique_id( $it['isbn'] );
			} catch ( \Exception $x ) {
				unset( $x );
			}
		}
		if ( isset( $it['price'] ) && $it['price'] > 0 ) {
			$p->set_regular_price( wc_format_decimal( $it['price'] ) );
		}
		$p->set_manage_stock( true );
		$p->set_stock_quantity( isset( $it['stock'] ) ? max( 0, (int) floor( $it['stock'] ) ) : 0 );
		$gm = self::group_map( $o['group_map'] );
		if ( ! empty( $it['group'] ) && isset( $gm[ $it['group'] ] ) ) {
			$p->set_category_ids( array( $gm[ $it['group'] ] ) );
		}
		$p->update_meta_data( $o['guid_meta_key'], $g );
		$p->save();
		return true;
	}

	/* ---------------------------------------------------------------- */
	/* Данные сайта                                                     */
	/* ---------------------------------------------------------------- */

	/**
	 * Одним запросом: GUID, SKU, остаток, цена, учёт остатков для всех товаров.
	 *
	 * @return array id => [guid, sku, stock, price, manage]
	 */
	private static function site_products( $guid_key ) {
		global $wpdb;
		$fields = array(
			$guid_key         => 'guid',
			'_sku'            => 'sku',
			'_stock'          => 'stock',
			'_regular_price'  => 'price',
			'_manage_stock'   => 'manage',
			'_global_unique_id' => 'isbn', // GTIN/UPC/EAN/ISBN в WooCommerce 9.2+.
		);
		$keys = array_keys( $fields );
		$in   = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql  = $wpdb->prepare( "SELECT pm.post_id, pm.meta_key, pm.meta_value FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.post_type = 'product' AND p.post_status NOT IN ('trash','auto-draft') AND pm.meta_key IN ($in)", $keys );
		$out  = array();
		foreach ( (array) $wpdb->get_results( $sql ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$id = (int) $r->post_id;
			if ( ! isset( $out[ $id ] ) ) {
				$out[ $id ] = array( 'guid' => '', 'sku' => '', 'stock' => '', 'price' => '', 'manage' => '', 'isbn' => '', 'title' => '' );
			}
			$out[ $id ][ $fields[ $r->meta_key ] ] = (string) $r->meta_value;
		}
		// Названия — для защиты от дублей при создании новых товаров.
		$titles = $wpdb->get_results( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status NOT IN ('trash','auto-draft')" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		foreach ( (array) $titles as $t ) {
			$id = (int) $t->ID;
			if ( ! isset( $out[ $id ] ) ) {
				$out[ $id ] = array( 'guid' => '', 'sku' => '', 'stock' => '', 'price' => '', 'manage' => '', 'isbn' => '', 'title' => '' );
			}
			$out[ $id ]['title'] = (string) $t->post_title;
		}
		return $out;
	}

	/** Количество в незавершённых онлайн-заказах: product_id => qty. */
	private static function reserved( array $statuses ) {
		$res = array();
		if ( ! $statuses ) {
			return $res;
		}
		$orders = wc_get_orders(
			array(
				'status' => $statuses,
				'limit'  => -1,
				'return' => 'objects',
			)
		);
		foreach ( $orders as $order ) {
			foreach ( $order->get_items() as $item ) {
				$pid         = (int) $item->get_product_id();
				$res[ $pid ] = ( isset( $res[ $pid ] ) ? $res[ $pid ] : 0 ) + (int) $item->get_quantity();
			}
		}
		return $res;
	}

	/** Строки «GUID группы = slug или ID категории» → [guid => term_id]. */
	private static function group_map( $text ) {
		$map = array();
		foreach ( preg_split( '/\R/', (string) $text ) as $line ) {
			if ( false === strpos( $line, '=' ) ) {
				continue;
			}
			list( $g, $t ) = array_map( 'trim', explode( '=', $line, 2 ) );
			$g             = FSYNC_Util::guid( $g );
			if ( '' === $g || '' === $t ) {
				continue;
			}
			if ( ctype_digit( $t ) ) {
				$map[ $g ] = (int) $t;
			} else {
				$term = get_term_by( 'slug', $t, 'product_cat' );
				if ( $term ) {
					$map[ $g ] = (int) $term->term_id;
				}
			}
		}
		return $map;
	}
}
