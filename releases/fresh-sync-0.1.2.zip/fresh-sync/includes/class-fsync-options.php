<?php
defined( 'ABSPATH' ) || exit;

class FSYNC_Options {

	const KEY = 'fsync_options';

	public static function defaults() {
		return array(
			// Источник данных.
			'source'                => 'csv', // csv | odata.
			'csv_location'          => '',
			'odata_base'            => '',
			'odata_user'            => '',
			'odata_pass'            => '',
			'odata_page_size'       => 1000,
			'odata_stock_entity'    => 'AccountingRegister_Хозрасчетный/Balance()',
			'odata_stock_item'      => 'Номенклатура_Key',
			'odata_stock_field'     => 'КоличествоBalance',
			'odata_stock_accounts'  => '41.01',
			'odata_chart_entity'    => 'ChartOfAccounts_Хозрасчетный',
			'odata_stock_wh_field'  => 'Склад_Key',
			'odata_warehouse_guid'  => '',
			'odata_price_entity'    => 'InformationRegister_ЦеныНоменклатуры',
			'odata_price_period_field' => 'Period',
			'odata_price_item'      => 'Номенклатура_Key',
			'odata_price_field'     => 'Цена',
			'odata_price_type_field' => 'ТипЦен_Key',
			'odata_price_type_guid' => '',
			'odata_catalog_entity'  => 'Catalog_Номенклатура',
			'flag_enabled'          => 0,
			'flag_need_stock'       => 1,
			'flag_property'         => 'Выгружать на сайт',
			'odata_flag_pvc'        => 'ChartOfCharacteristicTypes_ДополнительныеРеквизитыИСведения',
			'odata_flag_table'      => 'ДополнительныеРеквизиты',
			'odata_flag_key_field'  => 'Свойство_Key',
			'odata_flag_value_field' => 'Значение',
			// Поведение.
			'guid_meta_key'         => '_edi_1c_guid',
			'update_stock'          => 1,
			'update_price'          => 1,
			'skip_zero_price'       => 1,
			'link_by_sku'           => 1,
			'absent_is_zero'        => 1,
			'zero_guard_percent'    => 30,
			'max_changes'           => 0,
			'reserve_statuses'      => array( 'on-hold', 'processing' ),
			// Новые товары.
			'create_new'            => 0,
			'max_new_per_run'       => 200,
			'new_status'            => 'draft',
			'group_map'             => '',
			// Расписание.
			'interval_minutes'      => 0,
			'batch_seconds'         => 20,
		);
	}

	public static function get() {
		$o = array_merge( self::defaults(), (array) get_option( self::KEY, array() ) );
		// Прежнее значение по умолчанию для остатков (регистра ТоварыНаСкладах в этой базе нет).
		if ( 'AccumulationRegister_ТоварыНаСкладах/Balance()' === $o['odata_stock_entity'] ) {
			$o['odata_stock_entity'] = 'AccountingRegister_Хозрасчетный/Balance()';
			$o['odata_stock_field']  = 'КоличествоBalance';
		}
		// Старое значение по умолчанию (SliceLast) на практике давало HTTP 400.
		if ( 'InformationRegister_ЦеныНоменклатуры/SliceLast()' === $o['odata_price_entity'] ) {
			$o['odata_price_entity'] = 'InformationRegister_ЦеныНоменклатуры';
		}
		return $o;
	}

	/**
	 * Сохраняет настройки из $_POST (с очисткой значений).
	 */
	public static function save( array $post ) {
		$old = self::get();
		$new = $old;

		$strings = array(
			'csv_location',
			'odata_user',
			'odata_stock_entity',
			'odata_stock_item',
			'odata_stock_field',
			'odata_stock_wh_field',
			'odata_stock_accounts',
			'odata_chart_entity',
			'odata_warehouse_guid',
			'odata_price_entity',
			'odata_price_item',
			'odata_price_field',
			'odata_price_type_field',
			'odata_price_period_field',
			'odata_price_type_guid',
			'odata_catalog_entity',
			'flag_property',
			'odata_flag_pvc',
			'odata_flag_table',
			'odata_flag_key_field',
			'odata_flag_value_field',
		);
		foreach ( $strings as $k ) {
			if ( isset( $post[ $k ] ) ) {
				$new[ $k ] = trim( sanitize_text_field( wp_unslash( $post[ $k ] ) ) );
			}
		}
		foreach ( array( 'odata_warehouse_guid', 'odata_price_type_guid' ) as $k ) {
			$new[ $k ] = trim( strtolower( $new[ $k ] ), '{} ' );
		}

		if ( isset( $post['odata_base'] ) ) {
			$new['odata_base'] = rtrim( esc_url_raw( trim( wp_unslash( $post['odata_base'] ) ) ), '/' );
		}
		if ( isset( $post['odata_pass'] ) && '' !== $post['odata_pass'] ) {
			$new['odata_pass'] = wp_unslash( $post['odata_pass'] );
		}
		if ( isset( $post['group_map'] ) ) {
			$new['group_map'] = sanitize_textarea_field( wp_unslash( $post['group_map'] ) );
		}

		$key = isset( $post['guid_meta_key'] ) ? preg_replace( '/[^A-Za-z0-9_\-]/', '', wp_unslash( $post['guid_meta_key'] ) ) : '';
		if ( '' !== $key ) {
			$new['guid_meta_key'] = $key;
		}

		$new['source']     = ( isset( $post['source'] ) && 'odata' === $post['source'] ) ? 'odata' : 'csv';
		$new['new_status'] = ( isset( $post['new_status'] ) && 'pending' === $post['new_status'] ) ? 'pending' : 'draft';

		foreach ( array( 'update_stock', 'update_price', 'skip_zero_price', 'link_by_sku', 'absent_is_zero', 'create_new', 'flag_enabled', 'flag_need_stock' ) as $k ) {
			$new[ $k ] = empty( $post[ $k ] ) ? 0 : 1;
		}

		$ints = array(
			'odata_page_size'    => array( 100, 5000 ),
			'zero_guard_percent' => array( 0, 100 ),
			'max_changes'        => array( 0, 100000 ),
			'max_new_per_run'    => array( 0, 5000 ),
			'interval_minutes'   => array( 0, 1440 ),
			'batch_seconds'      => array( 5, 50 ),
		);
		foreach ( $ints as $k => $range ) {
			if ( isset( $post[ $k ] ) ) {
				$new[ $k ] = max( $range[0], min( $range[1], absint( $post[ $k ] ) ) );
			}
		}

		$valid = array();
		foreach ( array_keys( wc_get_order_statuses() ) as $s ) {
			$valid[] = 0 === strpos( $s, 'wc-' ) ? substr( $s, 3 ) : $s;
		}
		$sel = array();
		if ( ! empty( $post['reserve_statuses'] ) && is_array( $post['reserve_statuses'] ) ) {
			foreach ( $post['reserve_statuses'] as $s ) {
				$s = sanitize_key( wp_unslash( $s ) );
				if ( in_array( $s, $valid, true ) ) {
					$sel[] = $s;
				}
			}
		}
		$new['reserve_statuses'] = $sel;

		update_option( self::KEY, $new, false );
		return $new;
	}
}
